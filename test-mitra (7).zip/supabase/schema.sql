-- ==========================================================
-- TEST MITRA - Complete Supabase Database Schema
-- Tagline: "તમારી સફળતાની સાચી સાથી"
-- ==========================================================

-- 1. Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Create User Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'admin', 'super_admin')),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    allowed_categories TEXT[] DEFAULT ARRAY['Navodaya', 'NMMS', 'Gyan Setu', 'Gyan Sadhana', 'TET-1'],
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Create Exam Categories Table
CREATE TABLE IF NOT EXISTS public.exam_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    name_gu TEXT,
    description TEXT,
    icon_name TEXT DEFAULT 'GraduationCap',
    color_code TEXT DEFAULT '#4CAF50',
    bg_color TEXT DEFAULT '#E8F5E9',
    is_active BOOLEAN DEFAULT true,
    display_order INT DEFAULT 1,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Create Tests Table
CREATE TABLE IF NOT EXISTS public.tests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id UUID REFERENCES public.exam_categories(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    duration_minutes INT NOT NULL DEFAULT 30,
    question_limit INT NOT NULL DEFAULT 20,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. Create Questions Table
CREATE TABLE IF NOT EXISTS public.questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE NOT NULL,
    question_text TEXT NOT NULL,
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT NOT NULL,
    option_d TEXT NOT NULL,
    correct_option CHAR(1) NOT NULL CHECK (correct_option IN ('A', 'B', 'C', 'D')),
    explanation TEXT,
    question_order INT DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 6. Create Test Assignments Table
CREATE TABLE IF NOT EXISTS public.test_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE NOT NULL,
    assigned_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(student_id, test_id)
);

-- 7. Create Announcements Table
CREATE TABLE IF NOT EXISTS public.announcements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    category_id UUID REFERENCES public.exam_categories(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ==========================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

-- Allow public read access to active exam categories
CREATE POLICY "Allow public read access to active categories" 
ON public.exam_categories FOR SELECT USING (is_active = true);

-- Allow public read access to active tests
CREATE POLICY "Allow public read access to active tests" 
ON public.tests FOR SELECT USING (is_active = true);

-- Allow public read access to active questions for active tests
CREATE POLICY "Allow public read access to active questions" 
ON public.questions FOR SELECT USING (is_active = true);

-- Allow authenticated users to read and update their own profile
CREATE POLICY "Users can read own profile" 
ON public.profiles FOR SELECT USING (auth.uid() = user_id OR true);

CREATE POLICY "Allow public access for app client operations"
ON public.profiles FOR ALL USING (true);

CREATE POLICY "Allow public access for test assignments"
ON public.test_assignments FOR ALL USING (true);

CREATE POLICY "Allow public access for tests"
ON public.tests FOR ALL USING (true);

CREATE POLICY "Allow public access for questions"
ON public.questions FOR ALL USING (true);

CREATE POLICY "Allow public access for announcements"
ON public.announcements FOR ALL USING (true);

-- ==========================================================
-- SEED INITIAL EXAM CATEGORIES
-- ==========================================================

INSERT INTO public.exam_categories (slug, name, name_gu, description, icon_name, color_code, bg_color, is_active, display_order)
VALUES 
    ('navodaya', 'Navodaya', 'જવાહર નવોદય વિદ્યાલય પ્રવેશ પરીક્ષા', 'JNVST Class 6 and Class 9 Entrance Exam Practice', 'GraduationCap', '#10B981', '#E8F5E9', true, 1),
    ('nmms', 'NMMS', 'રાષ્ટ્રીય સાધન સહ શિષ્યવૃત્તિ પરીક્ષા', 'National Means-cum-Merit Scholarship Scheme Exam', 'Award', '#2563EB', '#E3F2FD', true, 2),
    ('gyan-setu', 'Gyan Setu', 'જ્ઞાન સેતુ સ્કોલરશિપ પરીક્ષા', 'Gyan Setu Merit Scholarship & Day School Entrance', 'BookOpen', '#F59E0B', '#FEF3C7', true, 3),
    ('gyan-sadhana', 'Gyan Sadhana', 'જ્ઞાન સાધના સ્કોલરશિપ પરીક્ષા', 'Mukhyamantri Gyan Sadhana Scholarship Examination', 'Sparkles', '#7C3AED', '#EDE9FE', true, 4),
    ('tet-1', 'TET-1', 'શિક્ષક યોગ્યતા કસોટી - ૧ (ધોરણ ૧ થી ૫)', 'Teacher Eligibility Test Paper 1 for Primary Teachers', 'Bookmark', '#EF4444', '#FEE2E2', true, 5)
ON CONFLICT (slug) DO NOTHING;
