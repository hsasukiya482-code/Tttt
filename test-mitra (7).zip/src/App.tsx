import React, { useState, useEffect } from 'react';
import { useNetworkStatus } from './lib/network';
import { dataService } from './lib/dataService';
import { Profile, ExamCategory, Test } from './lib/supabase';
import { AndroidFrame } from './components/AndroidFrame';
import { OfflineScreen } from './components/OfflineScreen';
import { SplashScreen } from './components/student/SplashScreen';
import { StudentLogin } from './components/student/StudentLogin';
import { StudentHome } from './components/student/StudentHome';
import { CategoryTestsScreen } from './components/student/CategoryTestsScreen';
import { TestScreen, TestResultData } from './components/student/TestScreen';
import { TestResultScreen } from './components/student/TestResultScreen';
import { StudentProfileScreen } from './components/student/StudentProfileScreen';
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminDashboard, AdminTab } from './components/admin/AdminDashboard';
import { ManageStudents } from './components/admin/ManageStudents';
import { ManageAdmins } from './components/admin/ManageAdmins';
import { ManageTests } from './components/admin/ManageTests';
import { ManageQuestions } from './components/admin/ManageQuestions';
import { TestAssignments } from './components/admin/TestAssignments';
import { SupabaseSettingsModal } from './components/admin/SupabaseSettingsModal';

type AppScreen =
  | 'splash'
  | 'student_login'
  | 'admin_login'
  | 'student_home'
  | 'category_tests'
  | 'test_active'
  | 'test_result'
  | 'student_profile'
  | 'admin_dashboard'
  | 'admin_students'
  | 'admin_admins'
  | 'admin_tests'
  | 'admin_questions'
  | 'admin_assignments';

export default function App() {
  const { isOnline, isChecking, checkConnection } = useNetworkStatus();
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('splash');
  const [currentUser, setCurrentUser] = useState<Profile | null>(null);

  // Flow State
  const [selectedCategory, setSelectedCategory] = useState<ExamCategory | null>(null);
  const [activeTest, setActiveTest] = useState<Test | null>(null);
  const [testResult, setTestResult] = useState<TestResultData | null>(null);
  const [managingQuestionsForTest, setManagingQuestionsForTest] = useState<Test | undefined>(undefined);
  const [isSupabaseModalOpen, setIsSupabaseModalOpen] = useState(false);

  // Initialize session on load
  useEffect(() => {
    const savedUser = dataService.getCurrentUser();
    if (savedUser) {
      setCurrentUser(savedUser);
    }
  }, []);

  // Theme determination for Android Status Bar
  const getAppTheme = (): 'student' | 'admin' | 'neutral' => {
    if (
      currentScreen === 'admin_login' ||
      currentScreen === 'admin_dashboard' ||
      currentScreen === 'admin_students' ||
      currentScreen === 'admin_admins' ||
      currentScreen === 'admin_tests' ||
      currentScreen === 'admin_questions' ||
      currentScreen === 'admin_assignments'
    ) {
      return 'admin';
    }
    if (
      currentScreen === 'student_home' ||
      currentScreen === 'category_tests' ||
      currentScreen === 'test_active' ||
      currentScreen === 'test_result' ||
      currentScreen === 'student_profile' ||
      currentScreen === 'student_login'
    ) {
      return 'student';
    }
    return 'neutral';
  };

  // Internet required gate
  if (!isOnline) {
    return (
      <AndroidFrame theme="neutral">
        <OfflineScreen onRetry={checkConnection} isChecking={isChecking} />
      </AndroidFrame>
    );
  }

  // Handle Splash completion
  const handleSplashFinish = () => {
    if (currentUser) {
      if (currentUser.role === 'admin' || currentUser.role === 'super_admin') {
        setCurrentScreen('admin_dashboard');
      } else {
        setCurrentScreen('student_home');
      }
    } else {
      setCurrentScreen('student_login');
    }
  };

  // Student login success
  const handleStudentLoginSuccess = (profile: Profile) => {
    setCurrentUser(profile);
    setCurrentScreen('student_home');
  };

  // Admin login success
  const handleAdminLoginSuccess = (profile: Profile) => {
    setCurrentUser(profile);
    setCurrentScreen('admin_dashboard');
  };

  // Logout
  const handleLogout = () => {
    dataService.setCurrentUser(null);
    setCurrentUser(null);
    setCurrentScreen('student_login');
  };

  // Student test flow handlers
  const handleSelectCategory = (category: ExamCategory) => {
    setSelectedCategory(category);
    setCurrentScreen('category_tests');
  };

  const handleStartTest = (test: Test) => {
    setActiveTest(test);
    setCurrentScreen('test_active');
  };

  const handleCompleteTest = (result: TestResultData) => {
    setTestResult(result);
    setCurrentScreen('test_result');
  };

  const handleRetakeTest = () => {
    if (activeTest) {
      setCurrentScreen('test_active');
    } else if (selectedCategory) {
      setCurrentScreen('category_tests');
    } else {
      setCurrentScreen('student_home');
    }
  };

  // Admin navigation
  const handleAdminNavigate = (tab: AdminTab) => {
    switch (tab) {
      case 'dashboard':
        setCurrentScreen('admin_dashboard');
        break;
      case 'students':
        setCurrentScreen('admin_students');
        break;
      case 'admins':
        setCurrentScreen('admin_admins');
        break;
      case 'tests':
        setCurrentScreen('admin_tests');
        break;
      case 'questions':
        setManagingQuestionsForTest(undefined);
        setCurrentScreen('admin_questions');
        break;
      case 'assignments':
        setCurrentScreen('admin_assignments');
        break;
    }
  };

  return (
    <AndroidFrame theme={getAppTheme()}>
      {/* 1. Splash Screen */}
      {currentScreen === 'splash' && (
        <SplashScreen onFinish={handleSplashFinish} />
      )}

      {/* 2. Student Login */}
      {currentScreen === 'student_login' && (
        <StudentLogin
          onLoginSuccess={handleStudentLoginSuccess}
          onSwitchToAdmin={() => setCurrentScreen('admin_login')}
        />
      )}

      {/* 3. Student Home */}
      {currentScreen === 'student_home' && currentUser && (
        <StudentHome
          student={currentUser}
          onSelectCategory={handleSelectCategory}
          onGoToProfile={() => setCurrentScreen('student_profile')}
        />
      )}

      {/* 4. Category Tests Screen */}
      {currentScreen === 'category_tests' && selectedCategory && (
        <CategoryTestsScreen
          category={selectedCategory}
          onBack={() => setCurrentScreen('student_home')}
          onStartTest={handleStartTest}
        />
      )}

      {/* 5. Interactive Test Screen */}
      {currentScreen === 'test_active' && activeTest && (
        <TestScreen
          test={activeTest}
          onQuit={() => setCurrentScreen('category_tests')}
          onComplete={handleCompleteTest}
        />
      )}

      {/* 6. Test Result Screen (Temporary session result, no permanent history) */}
      {currentScreen === 'test_result' && testResult && (
        <TestResultScreen
          result={testResult}
          onBackToHome={() => setCurrentScreen('student_home')}
          onRetakeTest={handleRetakeTest}
        />
      )}

      {/* 7. Student Profile Screen */}
      {currentScreen === 'student_profile' && currentUser && (
        <StudentProfileScreen
          student={currentUser}
          onBack={() => setCurrentScreen('student_home')}
          onLogout={handleLogout}
        />
      )}

      {/* 8. Admin Login */}
      {currentScreen === 'admin_login' && (
        <AdminLogin
          onLoginSuccess={handleAdminLoginSuccess}
          onSwitchToStudent={() => setCurrentScreen('student_login')}
        />
      )}

      {/* 9. Admin Dashboard */}
      {currentScreen === 'admin_dashboard' && currentUser && (
        <AdminDashboard
          admin={currentUser}
          onNavigate={handleAdminNavigate}
          onLogout={handleLogout}
          onOpenSettings={() => setIsSupabaseModalOpen(true)}
        />
      )}

      {/* 10. Manage Students */}
      {currentScreen === 'admin_students' && (
        <ManageStudents
          onBack={() => setCurrentScreen('admin_dashboard')}
          onAssignTests={(std) => {
            setCurrentScreen('admin_assignments');
          }}
        />
      )}

      {/* 11. Manage Admins */}
      {currentScreen === 'admin_admins' && (
        <ManageAdmins onBack={() => setCurrentScreen('admin_dashboard')} />
      )}

      {/* 12. Manage Tests */}
      {currentScreen === 'admin_tests' && (
        <ManageTests
          onBack={() => setCurrentScreen('admin_dashboard')}
          onManageQuestions={(test) => {
            setManagingQuestionsForTest(test);
            setCurrentScreen('admin_questions');
          }}
        />
      )}

      {/* 13. Manage Questions */}
      {currentScreen === 'admin_questions' && (
        <ManageQuestions
          test={managingQuestionsForTest}
          onBack={() => {
            if (managingQuestionsForTest) {
              setCurrentScreen('admin_tests');
            } else {
              setCurrentScreen('admin_dashboard');
            }
          }}
        />
      )}

      {/* 14. Test Assignments */}
      {currentScreen === 'admin_assignments' && (
        <TestAssignments
          onBack={() => setCurrentScreen('admin_dashboard')}
        />
      )}

      {/* Supabase Configuration & SQL Schema Modal */}
      <SupabaseSettingsModal
        isOpen={isSupabaseModalOpen}
        onClose={() => setIsSupabaseModalOpen(false)}
      />
    </AndroidFrame>
  );
}
