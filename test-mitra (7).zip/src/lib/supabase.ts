import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Configuration keys for local storage overrides or environment variables
const STORAGE_KEY_URL = 'testmitra_supabase_url';
const STORAGE_KEY_ANON = 'testmitra_supabase_anon_key';

// Default Supabase configuration (fallback / environment variables)
const DEFAULT_SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://cycsgbjcstznpticoauc.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_0ntwUPRm5DksYucuVWEedQ_DR4nxsE7';

export function getSupabaseConfig() {
  const customUrl = localStorage.getItem(STORAGE_KEY_URL);
  const customKey = localStorage.getItem(STORAGE_KEY_ANON);
  return {
    url: customUrl || DEFAULT_SUPABASE_URL,
    anonKey: customKey || DEFAULT_SUPABASE_ANON_KEY,
    isCustom: !!(customUrl && customKey),
  };
}

export function saveSupabaseConfig(url: string, anonKey: string) {
  if (url && anonKey) {
    localStorage.setItem(STORAGE_KEY_URL, url.trim());
    localStorage.setItem(STORAGE_KEY_ANON, anonKey.trim());
    supabaseInstance = createClient(url.trim(), anonKey.trim());
  }
}

export function resetSupabaseConfig() {
  localStorage.removeItem(STORAGE_KEY_URL);
  localStorage.removeItem(STORAGE_KEY_ANON);
  const config = getSupabaseConfig();
  supabaseInstance = createClient(config.url, config.anonKey);
}

let supabaseInstance: SupabaseClient = createClient(
  getSupabaseConfig().url,
  getSupabaseConfig().anonKey
);

export const supabase = new Proxy({} as SupabaseClient, {
  get(_target, prop) {
    return (supabaseInstance as any)[prop];
  },
});

export interface Profile {
  id: string;
  full_name: string;
  phone: string;
  role: 'student' | 'admin' | 'super_admin';
  status: 'active' | 'inactive';
  allowed_categories?: string[];
  created_at?: string;
  updated_at?: string;
}

export interface ExamCategory {
  id: string;
  slug: string;
  name: string;
  name_gu?: string;
  description: string;
  icon_name: string;
  color_code: string;
  bg_color: string;
  is_active: boolean;
  display_order: number;
}

export interface Test {
  id: string;
  category_id: string;
  title: string;
  description?: string;
  duration_minutes: number;
  question_limit: number;
  is_active: boolean;
  created_at?: string;
  category?: ExamCategory;
}

export interface Question {
  id: string;
  test_id: string;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: 'A' | 'B' | 'C' | 'D';
  explanation?: string;
  question_order: number;
  is_active: boolean;
}

export interface TestAssignment {
  id: string;
  student_id: string;
  test_id: string;
  assigned_by?: string;
  created_at?: string;
  student?: Profile;
  test?: Test;
}

export interface Announcement {
  id: string;
  title: string;
  message: string;
  category_id?: string;
  is_active: boolean;
  created_at?: string;
}
