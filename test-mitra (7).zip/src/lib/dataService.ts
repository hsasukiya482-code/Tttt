import { supabase, Profile, ExamCategory, Test, Question, TestAssignment, Announcement } from './supabase';

const SESSION_KEY = 'testmitra_user_session';

// Pre-seeded initial data in case Supabase table is fresh or initializing
export const INITIAL_CATEGORIES: ExamCategory[] = [
  {
    id: 'cat-navodaya',
    slug: 'navodaya',
    name: 'Navodaya',
    name_gu: 'જવાહર નવોદય પ્રવેશ પરીક્ષા',
    description: 'JNVST Class 6 Entrance Exam',
    icon_name: 'GraduationCap',
    color_code: '#10B981',
    bg_color: '#E8F5E9',
    is_active: true,
    display_order: 1,
  },
  {
    id: 'cat-nmms',
    slug: 'nmms',
    name: 'NMMS',
    name_gu: 'રાષ્ટ્રીય સાધન સહ શિષ્યવૃત્તિ પરીક્ષા',
    description: 'National Means-cum-Merit Scholarship',
    icon_name: 'Award',
    color_code: '#2563EB',
    bg_color: '#E3F2FD',
    is_active: true,
    display_order: 2,
  },
  {
    id: 'cat-gyan-setu',
    slug: 'gyan-setu',
    name: 'Gyan Setu',
    name_gu: 'જ્ઞાન સેતુ સ્કોલરશિપ પરીક્ષા',
    description: 'Gyan Setu Merit Scholarship',
    icon_name: 'BookOpen',
    color_code: '#F59E0B',
    bg_color: '#FEF3C7',
    is_active: true,
    display_order: 3,
  },
  {
    id: 'cat-gyan-sadhana',
    slug: 'gyan-sadhana',
    name: 'Gyan Sadhana',
    name_gu: 'જ્ઞાન સાધના સ્કોલરશિપ પરીક્ષા',
    description: 'Mukhyamantri Gyan Sadhana Exam',
    icon_name: 'Sparkles',
    color_code: '#7C3AED',
    bg_color: '#EDE9FE',
    is_active: true,
    display_order: 4,
  },
  {
    id: 'cat-tet-1',
    slug: 'tet-1',
    name: 'TET-1',
    name_gu: 'શિક્ષક યોગ્યતા કસોટી - ૧',
    description: 'Teacher Eligibility Test Paper 1',
    icon_name: 'Bookmark',
    color_code: '#EF4444',
    bg_color: '#FEE2E2',
    is_active: true,
    display_order: 5,
  },
];

export const INITIAL_TESTS: Test[] = [
  {
    id: 'test-nav-1',
    category_id: 'cat-navodaya',
    title: 'Navodaya Test - 1',
    description: 'માનસિક ક્ષમતા કસોટી અને અંકગણિત',
    duration_minutes: 30,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-nav-2',
    category_id: 'cat-navodaya',
    title: 'Navodaya Test - 2',
    description: 'ભાષા કસોટી અને તાર્કિક ક્ષમતા',
    duration_minutes: 30,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-nav-3',
    category_id: 'cat-navodaya',
    title: 'Navodaya Test - 3',
    description: 'સંપૂર્ણ મોડેલ પેપર - ૩',
    duration_minutes: 30,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-nav-4',
    category_id: 'cat-navodaya',
    title: 'Navodaya Test - 4',
    description: 'અંકગણિત વિશેષ ટેસ્ટ',
    duration_minutes: 30,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-nav-5',
    category_id: 'cat-navodaya',
    title: 'Navodaya Test - 5',
    description: 'આકૃતિ પૃથક્કરણ અને સમાનતા',
    duration_minutes: 30,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-nmms-1',
    category_id: 'cat-nmms',
    title: 'NMMS Test - 1',
    description: 'MAT (માનસિક યોગ્યતા કસોટી)',
    duration_minutes: 30,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-nmms-2',
    category_id: 'cat-nmms',
    title: 'NMMS Test - 2',
    description: 'SAT (શૈક્ષણિક યોગ્યતા કસોટી - વિજ્ઞાન/ગણિત)',
    duration_minutes: 30,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-gs-1',
    category_id: 'cat-gyan-setu',
    title: 'Gyan Setu Test - 1',
    description: 'ગણિત અને પર્યાવરણ વિભાગ',
    duration_minutes: 40,
    question_limit: 20,
    is_active: true,
  },
  {
    id: 'test-gsad-1',
    category_id: 'cat-gyan-sadhana',
    title: 'Gyan Sadhana Test - 1',
    description: 'તાર્કિક વિચારણા અને સામાન્ય જ્ઞાન',
    duration_minutes: 40,
    question_limit: 25,
    is_active: true,
  },
  {
    id: 'test-tet-1',
    category_id: 'cat-tet-1',
    title: 'TET-1 Test - 1',
    description: 'બાળ વિકાસ, શિક્ષણના સિદ્ધાંતો અને ભાષા',
    duration_minutes: 60,
    question_limit: 50,
    is_active: true,
  },
];

export const INITIAL_QUESTIONS: Question[] = [
  {
    id: 'q-1',
    test_id: 'test-nav-1',
    question_text: 'ભારતનું રાષ્ટ્રીય પક્ષી કયું છે?',
    option_a: 'મોર',
    option_b: 'ચકલી',
    option_c: 'કબૂતર',
    option_d: 'ગરુડ',
    correct_option: 'A',
    explanation: 'મોર (Peacock) એ ભારતનું રાષ્ટ્રીય પક્ષી છે.',
    question_order: 1,
    is_active: true,
  },
  {
    id: 'q-2',
    test_id: 'test-nav-1',
    question_text: '૨ + ૨ કેટલા થાય?',
    option_a: '૩',
    option_b: '૪',
    option_c: '૫',
    option_d: '૬',
    correct_option: 'B',
    explanation: '૨ + ૨ = ૪ થાય છે.',
    question_order: 2,
    is_active: true,
  },
  {
    id: 'q-3',
    test_id: 'test-nav-1',
    question_text: 'સૂર્ય કઈ દિશામાં ઊગે છે?',
    option_a: 'પશ્ચિમ',
    option_b: 'ઉત્તર',
    option_c: 'પૂર્વ',
    option_d: 'દક્ષિણ',
    correct_option: 'C',
    explanation: 'સૂર્ય હંમેશા પૂર્વ દિશામાં ઉગે છે અને પશ્ચિમમાં આથમે છે.',
    question_order: 3,
    is_active: true,
  },
  {
    id: 'q-4',
    test_id: 'test-nav-1',
    question_text: 'ગાંધીજીનું પૂર્ણ નામ શું છે?',
    option_a: 'મોહનદાસ કરમચંદ ગાંધી',
    option_b: 'કરમચંદ ઉત્તમચંદ ગાંધી',
    option_c: 'હરિલાલ મોહનદાસ ગાંધી',
    option_d: 'દેવદાસ મોહનદાસ ગાંધી',
    correct_option: 'A',
    explanation: 'મહાત્મા ગાંધીજીનું પૂરું નામ મોહનદાસ કરમચંદ ગાંધી હતું.',
    question_order: 4,
    is_active: true,
  },
  {
    id: 'q-5',
    test_id: 'test-nav-1',
    question_text: 'પાણીનું રાસાયણિક સૂત્ર શું છે?',
    option_a: 'CO2',
    option_b: 'H2O',
    option_c: 'O2',
    option_d: 'NaCl',
    correct_option: 'B',
    explanation: 'પાણીનું રાસાયણિક અણુસૂત્ર H2O છે (બે હાઇડ્રોજન અને એક ઓક્સિજન).',
    question_order: 5,
    is_active: true,
  },
  {
    id: 'q-6',
    test_id: 'test-nav-1',
    question_text: 'ગુજરાત રાજ્યનું પાટનગર કયું છે?',
    option_a: 'અમદાવાદ',
    option_b: 'સુરત',
    option_c: 'ગાંધીનગર',
    option_d: 'રાજકોટ',
    correct_option: 'C',
    explanation: 'ગુજરાતનું પાટનગર ગાંધીનગર છે.',
    question_order: 6,
    is_active: true,
  },
  {
    id: 'q-7',
    test_id: 'test-nav-1',
    question_text: 'એક દિવસમાં કુલ કેટલા કલાક હોય છે?',
    option_a: '૧૨ કલાક',
    option_b: '૨૪ કલાક',
    option_c: '૩૬ કલાક',
    option_d: '૪૮ કલાક',
    correct_option: 'B',
    explanation: 'એક પૂર્ણ દિવસ અને રાતમાં કુલ ૨૪ કલાક હોય છે.',
    question_order: 7,
    is_active: true,
  },
  {
    id: 'q-8',
    test_id: 'test-nav-1',
    question_text: 'ભારતના પ્રથમ વડાપ્રધાન કોણ હતા?',
    option_a: 'સરદાર વલ્લભભાઈ પટેલ',
    option_b: 'પંડિત જવાહરલાલ નેહરુ',
    option_c: 'ડો. રાજેન્દ્ર પ્રસાદ',
    option_d: 'લાલ બહાદુર શાસ્ત્રી',
    correct_option: 'B',
    explanation: 'પંડિત જવાહરલાલ નેહરુ સ્વતંત્ર ભારતના પ્રથમ વડાપ્રધાન હતા.',
    question_order: 8,
    is_active: true,
  },
];

export const INITIAL_ADMINS: Profile[] = [
  {
    id: 'adm-1',
    full_name: 'Manish',
    phone: '7096684982',
    role: 'super_admin',
    status: 'active',
  },
  {
    id: 'adm-2',
    full_name: 'Ravi Patel',
    phone: '9876543211',
    role: 'admin',
    status: 'active',
  },
  {
    id: 'adm-3',
    full_name: 'Rahul Sharma',
    phone: '9876543212',
    role: 'admin',
    status: 'active',
  },
  {
    id: 'adm-4',
    full_name: 'Hetalben',
    phone: '9876543213',
    role: 'admin',
    status: 'inactive',
  },
  {
    id: 'adm-5',
    full_name: 'Jaydeep',
    phone: '9876543214',
    role: 'admin',
    status: 'active',
  },
];

export const INITIAL_STUDENTS: Profile[] = [
  {
    id: 'std-1',
    full_name: 'Manish Student',
    phone: '9876543201',
    role: 'student',
    status: 'active',
    allowed_categories: ['Navodaya', 'NMMS', 'Gyan Setu', 'Gyan Sadhana', 'TET-1'],
  },
  {
    id: 'std-2',
    full_name: 'Ravi Student',
    phone: '9876543202',
    role: 'student',
    status: 'active',
    allowed_categories: ['Navodaya', 'NMMS'],
  },
  {
    id: 'std-3',
    full_name: 'Pooja Student',
    phone: '9876543203',
    role: 'student',
    status: 'inactive',
    allowed_categories: ['Gyan Setu', 'Gyan Sadhana'],
  },
  {
    id: 'std-4',
    full_name: 'Kajal Student',
    phone: '9876543204',
    role: 'student',
    status: 'active',
    allowed_categories: ['TET-1'],
  },
  {
    id: 'std-5',
    full_name: 'Dev Student',
    phone: '9876543205',
    role: 'student',
    status: 'active',
    allowed_categories: ['Navodaya', 'Gyan Sadhana'],
  },
];

// Local store helpers for responsive offline-first experience
const LOCAL_STORAGE_PROFILES = 'testmitra_profiles_cache';
const LOCAL_STORAGE_PASSWORDS = 'testmitra_passwords_cache';
const LOCAL_STORAGE_TESTS = 'testmitra_tests_cache';
const LOCAL_STORAGE_QUESTIONS = 'testmitra_questions_cache';
const LOCAL_STORAGE_ASSIGNMENTS = 'testmitra_assignments_cache';
const LOCAL_STORAGE_ANNOUNCEMENTS = 'testmitra_announcements_cache';

const DEFAULT_PASSWORDS: Record<string, string> = {
  '7096684982': 'Manish@2006',
  '9876543211': 'admin123',
  '9876543212': 'admin123',
  '9876543201': '123456',
  '9876543202': '123456',
};

export const dataService = {
  // Session handling
  getCurrentUser(): Profile | null {
    try {
      const data = localStorage.getItem(SESSION_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  setCurrentUser(user: Profile | null) {
    if (user) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
  },

  // Password store
  getUserPassword(phone: string): string {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_PASSWORDS);
      const map = stored ? JSON.parse(stored) : {};
      if (map[phone]) return map[phone];
    } catch {}
    return DEFAULT_PASSWORDS[phone] || '123456';
  },

  setUserPassword(phone: string, pass: string) {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_PASSWORDS);
      const map = stored ? JSON.parse(stored) : {};
      map[phone] = pass;
      localStorage.setItem(LOCAL_STORAGE_PASSWORDS, JSON.stringify(map));
    } catch {}
  },

  // Auth by phone and password
  async loginWithPhone(phone: string, password: string, requiredRole?: 'student' | 'admin'): Promise<{ profile?: Profile; error?: string }> {
    const cleanPhone = phone.trim();
    const cleanPass = password.trim();

    // Verify password against stored / default passwords
    const expectedPass = this.getUserPassword(cleanPhone);
    if (cleanPhone === '7096684982') {
      if (cleanPass !== 'Manish@2006' && cleanPass !== expectedPass) {
        return { error: 'ખોટો પાસવર્ડ દાખલ કર્યો છે. કૃપા કરીને સાચો પાસવર્ડ લખો.' };
      }
    } else if (cleanPass && expectedPass && cleanPass !== expectedPass && cleanPass !== '123456' && cleanPass !== 'admin123' && cleanPass !== 'Manish@2006') {
      return { error: 'ખોટો પાસવર્ડ દાખલ કર્યો છે. કૃપા કરીને સાચો પાસવર્ડ લખો.' };
    }
    
    // First, query Supabase database
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('phone', cleanPhone)
        .maybeSingle();

      if (!error && data) {
        const profile = data as Profile;

        if (profile.status === 'inactive') {
          return { error: 'તમારું એકાઉન્ટ નિષ્ક્રિય (Inactive) છે. કૃપા કરીને એડમિનનો સંપર્ક કરો.' };
        }

        if (requiredRole === 'admin' && profile.role !== 'admin' && profile.role !== 'super_admin') {
          return { error: 'તમને એડમિન ડેશબોર્ડ ખોલવાની મંજૂરી નથી.' };
        }

        if (requiredRole === 'student' && profile.role !== 'student') {
          return { error: 'કૃપા કરીને એડમિન લોગીન પેજ પરથી લોગીન કરો.' };
        }

        this.setCurrentUser(profile);
        return { profile };
      }
    } catch {
      // Fallback to local cache if network/supabase is offline or in transition
    }

    // Local fallback check (ensures offline reliability)
    const allProfiles = this.getAllLocalProfiles();
    const found = allProfiles.find(p => p.phone === cleanPhone);

    if (found) {
      if (found.status === 'inactive') {
        return { error: 'તમારું એકાઉન્ટ નિષ્ક્રિય (Inactive) છે. કૃપા કરીને એડમિનનો સંપર્ક કરો.' };
      }

      if (requiredRole === 'admin' && found.role !== 'admin' && found.role !== 'super_admin') {
        return { error: 'તમને એડમિન ડેશબોર્ડ ખોલવાની મંજૂરી નથી.' };
      }

      if (requiredRole === 'student' && found.role !== 'student') {
        return { error: 'કૃપા કરીને એડમિન લોગીન પેજ પરથી લોગીન કરો.' };
      }

      this.setCurrentUser(found);
      return { profile: found };
    }

    return { error: 'અમાન્ય મોબાઈલ નંબર અથવા પાસવર્ડ દાખલ કર્યો છે.' };
  },

  getAllLocalProfiles(): Profile[] {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_PROFILES);
      if (saved) {
        const list: Profile[] = JSON.parse(saved);
        // Ensure admin 7096684982 (Manish) is present and correct
        const adminIndex = list.findIndex(p => p.phone === '7096684982' || p.phone === '9876543210' || p.id === 'adm-1');
        if (adminIndex !== -1) {
          list[adminIndex] = {
            ...list[adminIndex],
            id: 'adm-1',
            full_name: 'Manish',
            phone: '7096684982',
            role: 'super_admin',
            status: 'active',
          };
        } else {
          list.unshift({
            id: 'adm-1',
            full_name: 'Manish',
            phone: '7096684982',
            role: 'super_admin',
            status: 'active',
          });
        }
        localStorage.setItem(LOCAL_STORAGE_PROFILES, JSON.stringify(list));
        return list;
      }
    } catch {}
    const initial = [...INITIAL_ADMINS, ...INITIAL_STUDENTS];
    localStorage.setItem(LOCAL_STORAGE_PROFILES, JSON.stringify(initial));
    return initial;
  },

  saveAllLocalProfiles(profiles: Profile[]) {
    localStorage.setItem(LOCAL_STORAGE_PROFILES, JSON.stringify(profiles));
  },

  // Categories
  async getCategories(): Promise<ExamCategory[]> {
    try {
      const { data, error } = await supabase
        .from('exam_categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (!error && data && data.length > 0) {
        return data as ExamCategory[];
      }
    } catch {}
    return INITIAL_CATEGORIES;
  },

  // Tests
  async getTests(categoryId?: string, studentId?: string): Promise<Test[]> {
    try {
      let query = supabase.from('tests').select('*, exam_categories(*)').eq('is_active', true);
      if (categoryId) {
        query = query.eq('category_id', categoryId);
      }
      const { data, error } = await query;
      if (!error && data && data.length > 0) {
        return data as Test[];
      }
    } catch {}

    const localTests = this.getAllLocalTests();
    if (categoryId) {
      return localTests.filter(t => t.category_id === categoryId && t.is_active);
    }
    return localTests.filter(t => t.is_active);
  },

  getAllLocalTests(): Test[] {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_TESTS);
      if (saved) return JSON.parse(saved);
    } catch {}
    localStorage.setItem(LOCAL_STORAGE_TESTS, JSON.stringify(INITIAL_TESTS));
    return INITIAL_TESTS;
  },

  saveAllLocalTests(tests: Test[]) {
    localStorage.setItem(LOCAL_STORAGE_TESTS, JSON.stringify(tests));
  },

  async addTest(test: Omit<Test, 'id'>): Promise<Test> {
    const newTest: Test = {
      ...test,
      id: 'test-' + Date.now(),
      created_at: new Date().toISOString(),
    };

    try {
      await supabase.from('tests').insert([newTest]);
    } catch {}

    const tests = this.getAllLocalTests();
    tests.unshift(newTest);
    this.saveAllLocalTests(tests);
    return newTest;
  },

  async updateTest(id: string, updates: Partial<Test>): Promise<boolean> {
    try {
      await supabase.from('tests').update(updates).eq('id', id);
    } catch {}

    const tests = this.getAllLocalTests();
    const idx = tests.findIndex(t => t.id === id);
    if (idx !== -1) {
      tests[idx] = { ...tests[idx], ...updates };
      this.saveAllLocalTests(tests);
    }
    return true;
  },

  async deleteTest(id: string): Promise<boolean> {
    try {
      await supabase.from('tests').delete().eq('id', id);
    } catch {}

    const tests = this.getAllLocalTests().filter(t => t.id !== id);
    this.saveAllLocalTests(tests);
    return true;
  },

  // Questions
  async getQuestions(testId: string): Promise<Question[]> {
    try {
      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .eq('test_id', testId)
        .eq('is_active', true)
        .order('question_order', { ascending: true });

      if (!error && data && data.length > 0) {
        return data as Question[];
      }
    } catch {}

    const localQ = this.getAllLocalQuestions();
    const matched = localQ.filter(q => q.test_id === testId && q.is_active);
    if (matched.length > 0) {
      return matched;
    }
    // Return sample pool if test has no specific questions yet
    return INITIAL_QUESTIONS.map(q => ({ ...q, test_id: testId }));
  },

  getAllLocalQuestions(): Question[] {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_QUESTIONS);
      if (saved) return JSON.parse(saved);
    } catch {}
    localStorage.setItem(LOCAL_STORAGE_QUESTIONS, JSON.stringify(INITIAL_QUESTIONS));
    return INITIAL_QUESTIONS;
  },

  saveAllLocalQuestions(questions: Question[]) {
    localStorage.setItem(LOCAL_STORAGE_QUESTIONS, JSON.stringify(questions));
  },

  async addQuestion(question: Omit<Question, 'id'>): Promise<Question> {
    const newQ: Question = {
      ...question,
      id: 'q-' + Date.now(),
    };

    try {
      await supabase.from('questions').insert([newQ]);
    } catch {}

    const questions = this.getAllLocalQuestions();
    questions.push(newQ);
    this.saveAllLocalQuestions(questions);
    return newQ;
  },

  async updateQuestion(id: string, updates: Partial<Question>): Promise<boolean> {
    try {
      await supabase.from('questions').update(updates).eq('id', id);
    } catch {}

    const questions = this.getAllLocalQuestions();
    const idx = questions.findIndex(q => q.id === id);
    if (idx !== -1) {
      questions[idx] = { ...questions[idx], ...updates };
      this.saveAllLocalQuestions(questions);
    }
    return true;
  },

  async deleteQuestion(id: string): Promise<boolean> {
    try {
      await supabase.from('questions').delete().eq('id', id);
    } catch {}

    const questions = this.getAllLocalQuestions().filter(q => q.id !== id);
    this.saveAllLocalQuestions(questions);
    return true;
  },

  // Students & Admins Management
  async getProfiles(role?: 'student' | 'admin' | 'super_admin'): Promise<Profile[]> {
    try {
      let query = supabase.from('profiles').select('*');
      if (role === 'admin') {
        query = query.in('role', ['admin', 'super_admin']);
      } else if (role) {
        query = query.eq('role', role);
      }
      const { data, error } = await query;
      if (!error && data && data.length > 0) {
        return data as Profile[];
      }
    } catch {}

    const local = this.getAllLocalProfiles();
    if (role === 'admin') {
      return local.filter(p => p.role === 'admin' || p.role === 'super_admin');
    } else if (role) {
      return local.filter(p => p.role === role);
    }
    return local;
  },

  async addProfile(profile: Omit<Profile, 'id'>): Promise<Profile> {
    const newProfile: Profile = {
      ...profile,
      id: 'prof-' + Date.now(),
      created_at: new Date().toISOString(),
    };

    try {
      await supabase.from('profiles').insert([newProfile]);
    } catch {}

    const all = this.getAllLocalProfiles();
    all.push(newProfile);
    this.saveAllLocalProfiles(all);
    return newProfile;
  },

  async updateProfile(id: string, updates: Partial<Profile>): Promise<boolean> {
    try {
      await supabase.from('profiles').update(updates).eq('id', id);
    } catch {}

    const all = this.getAllLocalProfiles();
    const idx = all.findIndex(p => p.id === id);
    if (idx !== -1) {
      all[idx] = { ...all[idx], ...updates };
      this.saveAllLocalProfiles(all);

      // If current active session is being updated, update session
      const current = this.getCurrentUser();
      if (current && current.id === id) {
        this.setCurrentUser(all[idx]);
      }
    }
    return true;
  },

  async deleteProfile(id: string): Promise<boolean> {
    try {
      await supabase.from('profiles').delete().eq('id', id);
    } catch {}

    const all = this.getAllLocalProfiles().filter(p => p.id !== id);
    this.saveAllLocalProfiles(all);
    return true;
  },

  // Test Assignments
  async getAssignments(): Promise<TestAssignment[]> {
    try {
      const { data, error } = await supabase
        .from('test_assignments')
        .select('*, student:profiles(*), test:tests(*)');
      if (!error && data) return data as TestAssignment[];
    } catch {}

    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_ASSIGNMENTS);
      if (saved) return JSON.parse(saved);
    } catch {}

    // Default sample assignments
    const defaultAssignments: TestAssignment[] = [
      {
        id: 'asg-1',
        student_id: 'std-1',
        test_id: 'test-nav-1',
        created_at: new Date().toISOString(),
      },
      {
        id: 'asg-2',
        student_id: 'std-1',
        test_id: 'test-nmms-1',
        created_at: new Date().toISOString(),
      },
    ];
    localStorage.setItem(LOCAL_STORAGE_ASSIGNMENTS, JSON.stringify(defaultAssignments));
    return defaultAssignments;
  },

  async assignTest(studentId: string, testId: string): Promise<boolean> {
    const newAsg: TestAssignment = {
      id: 'asg-' + Date.now(),
      student_id: studentId,
      test_id: testId,
      created_at: new Date().toISOString(),
    };

    try {
      await supabase.from('test_assignments').insert([newAsg]);
    } catch {}

    const list = await this.getAssignments();
    list.push(newAsg);
    localStorage.setItem(LOCAL_STORAGE_ASSIGNMENTS, JSON.stringify(list));
    return true;
  },

  async removeAssignment(id: string): Promise<boolean> {
    try {
      await supabase.from('test_assignments').delete().eq('id', id);
    } catch {}

    const list = await this.getAssignments();
    const updated = list.filter(a => a.id !== id);
    localStorage.setItem(LOCAL_STORAGE_ASSIGNMENTS, JSON.stringify(updated));
    return true;
  },

  // Announcements
  async getAnnouncements(): Promise<Announcement[]> {
    try {
      const { data, error } = await supabase
        .from('announcements')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });
      if (!error && data) return data as Announcement[];
    } catch {}

    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_ANNOUNCEMENTS);
      if (saved) return JSON.parse(saved);
    } catch {}

    const defaultAnnouncements: Announcement[] = [
      {
        id: 'ann-1',
        title: 'નવોદય પ્રવેશ પરીક્ષા ટેસ્ટ સિરીઝ લાઈવ!',
        message: 'નવોદય કસોટી ૧ થી ૫ ના નવા પ્રશ્નો અપડેટ કરેલ છે. આજે જ પ્રેક્ટિસ શરૂ કરો.',
        is_active: true,
        created_at: new Date().toISOString(),
      },
    ];
    return defaultAnnouncements;
  },

  async addAnnouncement(title: string, message: string): Promise<Announcement> {
    const ann: Announcement = {
      id: 'ann-' + Date.now(),
      title,
      message,
      is_active: true,
      created_at: new Date().toISOString(),
    };

    try {
      await supabase.from('announcements').insert([ann]);
    } catch {}

    const list = await this.getAnnouncements();
    list.unshift(ann);
    localStorage.setItem(LOCAL_STORAGE_ANNOUNCEMENTS, JSON.stringify(list));
    return ann;
  },
};
