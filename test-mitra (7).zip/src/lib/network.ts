import { useEffect, useState } from 'react';

export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isChecking, setIsChecking] = useState<boolean>(false);

  const checkConnection = async (): Promise<boolean> => {
    setIsChecking(true);
    if (!navigator.onLine) {
      setIsOnline(false);
      setIsChecking(false);
      return false;
    }

    try {
      // Fast ping check
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);
      
      const response = await fetch('https://www.google.com/favicon.ico', {
        method: 'HEAD',
        mode: 'no-cors',
        cache: 'no-store',
        signal: controller.signal,
      }).catch(() => null);

      clearTimeout(timeoutId);
      const online = !!response || navigator.onLine;
      setIsOnline(online);
      setIsChecking(false);
      return online;
    } catch {
      setIsOnline(navigator.onLine);
      setIsChecking(false);
      return navigator.onLine;
    }
  };

  useEffect(() => {
    const handleOnline = () => checkConnection();
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return { isOnline, isChecking, checkConnection };
}
