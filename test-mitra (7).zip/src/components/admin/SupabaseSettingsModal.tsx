import React, { useState } from 'react';
import { Database, Copy, Check, Key, Globe, Shield, Terminal, Lock, AlertCircle, ShieldCheck } from 'lucide-react';
import { getSupabaseConfig, saveSupabaseConfig, resetSupabaseConfig } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface SupabaseSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SupabaseSettingsModal: React.FC<SupabaseSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const currentConfig = getSupabaseConfig();
  const [url, setUrl] = useState(currentConfig.url);
  const [anonKey, setAnonKey] = useState(currentConfig.anonKey);
  const [copied, setCopied] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [activeTab, setActiveTab] = useState<'config' | 'sql'>('config');

  // Master Security Lock State
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');

  if (!isOpen) return null;

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = adminPasswordInput.trim();
    const expectedPass = dataService.getUserPassword('7096684982') || 'Manish@2006';

    if (clean === expectedPass || clean === 'Manish@2006') {
      setIsUnlocked(true);
      setPasswordError('');
      setAdminPasswordInput('');
    } else {
      setPasswordError('અમાન્ય સુપર એડમિન પાસવર્ડ. કૃપા કરીને સાચો પાસવર્ડ દાખલ કરો.');
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || !anonKey.trim()) {
      setStatusMessage('Please enter both Supabase URL and Anon Key.');
      return;
    }
    saveSupabaseConfig(url, anonKey);
    setStatusMessage('✓ Supabase credentials saved successfully!');
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  const handleReset = () => {
    resetSupabaseConfig();
    const cfg = getSupabaseConfig();
    setUrl(cfg.url);
    setAnonKey(cfg.anonKey);
    setStatusMessage('Reset to default configuration.');
  };

  const handleModalClose = () => {
    setIsUnlocked(false);
    setAdminPasswordInput('');
    setPasswordError('');
    onClose();
  };

  const schemaSQL = `-- ==========================================================
-- TEST MITRA - Complete Supabase Database Schema
-- Tagline: "તમારી સફળતાની સાચી સાથી"
-- ==========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'admin', 'super_admin')),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    allowed_categories TEXT[] DEFAULT ARRAY['Navodaya', 'NMMS', 'Gyan Setu', 'Gyan Sadhana', 'TET-1'],
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.exam_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    name_gu TEXT,
    description TEXT,
    icon_name TEXT DEFAULT 'GraduationCap',
    color_code TEXT DEFAULT '#4CAF50',
    bg_color TEXT DEFAULT '#E8F5E9',
    is_active BOOLEAN DEFAULT true,
    display_order INT DEFAULT 1,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.tests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    category_id UUID REFERENCES public.exam_categories(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    duration_minutes INT NOT NULL DEFAULT 30,
    question_limit INT NOT NULL DEFAULT 20,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE NOT NULL,
    question_text TEXT NOT NULL,
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT NOT NULL,
    option_d TEXT NOT NULL,
    correct_option CHAR(1) NOT NULL CHECK (correct_option IN ('A', 'B', 'C', 'D')),
    explanation TEXT,
    question_order INT DEFAULT 1,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS public.test_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    test_id UUID REFERENCES public.tests(id) ON DELETE CASCADE NOT NULL,
    assigned_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    UNIQUE(student_id, test_id)
);

CREATE TABLE IF NOT EXISTS public.announcements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    category_id UUID REFERENCES public.exam_categories(id) ON DELETE SET NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.test_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to active categories" ON public.exam_categories FOR SELECT USING (is_active = true);
CREATE POLICY "Allow public read access to active tests" ON public.tests FOR SELECT USING (is_active = true);
CREATE POLICY "Allow public read access to active questions" ON public.questions FOR SELECT USING (is_active = true);
CREATE POLICY "Allow all access to profiles" ON public.profiles FOR ALL USING (true);
CREATE POLICY "Allow all access to tests" ON public.tests FOR ALL USING (true);
CREATE POLICY "Allow all access to questions" ON public.questions FOR ALL USING (true);
CREATE POLICY "Allow all access to assignments" ON public.test_assignments FOR ALL USING (true);
CREATE POLICY "Allow all access to announcements" ON public.announcements FOR ALL USING (true);

INSERT INTO public.exam_categories (slug, name, name_gu, description, icon_name, color_code, bg_color, is_active, display_order)
VALUES 
    ('navodaya', 'Navodaya', 'જવાહર નવોદય વિદ્યાલય પ્રવેશ પરીક્ષા', 'JNVST Class 6 Entrance Exam', 'GraduationCap', '#10B981', '#E8F5E9', true, 1),
    ('nmms', 'NMMS', 'રાષ્ટ્રીય સાધન સહ શિષ્યવૃત્તિ પરીક્ષા', 'National Means-cum-Merit Scholarship', 'Award', '#2563EB', '#E3F2FD', true, 2),
    ('gyan-setu', 'Gyan Setu', 'જ્ઞાન સેતુ સ્કોલરશિપ પરીક્ષા', 'Gyan Setu Merit Scholarship', 'BookOpen', '#F59E0B', '#FEF3C7', true, 3),
    ('gyan-sadhana', 'Gyan Sadhana', 'જ્ઞાન સાધના સ્કોલરશિપ પરીક્ષા', 'Mukhyamantri Gyan Sadhana Exam', 'Sparkles', '#7C3AED', '#EDE9FE', true, 4),
    ('tet-1', 'TET-1', 'શિક્ષક યોગ્યતા કસોટી - ૧', 'Teacher Eligibility Test Paper 1', 'Bookmark', '#EF4444', '#FEE2E2', true, 5)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.profiles (full_name, phone, role, status)
VALUES ('Manish', '7096684982', 'super_admin', 'active')
ON CONFLICT (phone) DO UPDATE SET full_name = 'Manish', role = 'super_admin', status = 'active';
`;

  const handleCopySQL = () => {
    navigator.clipboard.writeText(schemaSQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 flex items-center justify-center text-blue-800">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 leading-none">Database Security</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">Super Admin Restricted</p>
            </div>
          </div>
          <button
            onClick={handleModalClose}
            className="w-7 h-7 flex items-center justify-center rounded-full bg-slate-100 text-slate-500 hover:text-slate-700 hover:bg-slate-200 text-xs font-bold"
          >
            ✕
          </button>
        </div>

        {/* Security Password Lock Form if not unlocked */}
        {!isUnlocked ? (
          <form onSubmit={handleUnlock} className="space-y-4 py-2">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-100 mx-auto flex items-center justify-center text-amber-600">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">સુપર એડમિન વેરિફિકેશન</h4>
                <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                  ડેટાબેઝ સેટિંગ્સ સુરક્ષિત છે. એક્સેસ મેળવવા માટે સુપર એડમિન પાસવર્ડ દાખલ કરો.
                </p>
              </div>
            </div>

            {passwordError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{passwordError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Admin Password
              </label>
              <input
                type="password"
                value={adminPasswordInput}
                onChange={(e) => setAdminPasswordInput(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                autoFocus
              />
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={handleModalClose}
                className="w-1/3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors"
              >
                રદ કરો
              </button>
              <button
                type="submit"
                className="w-2/3 py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>અનલોક કરો</span>
              </button>
            </div>
          </form>
        ) : (
          <>
            {/* Tab Selector */}
            <div className="flex rounded-xl bg-slate-100 p-1 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('config')}
                className={`flex-1 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                  activeTab === 'config'
                    ? 'bg-white text-blue-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Key className="w-3.5 h-3.5" />
                <span>Connection</span>
              </button>
              <button
                onClick={() => setActiveTab('sql')}
                className={`flex-1 py-1.5 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                  activeTab === 'sql'
                    ? 'bg-white text-blue-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>SQL Schema</span>
              </button>
            </div>

            {statusMessage && (
              <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-blue-800 text-xs">
                {statusMessage}
              </div>
            )}

            {activeTab === 'config' ? (
              <form onSubmit={handleSave} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Supabase Project URL
                  </label>
                  <div className="relative">
                    <Globe className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="url"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      placeholder="https://your-project.supabase.co"
                      className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Public / Anon Publishable Key
                  </label>
                  <div className="relative">
                    <Shield className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <textarea
                      value={anonKey}
                      onChange={(e) => setAnonKey(e.target.value)}
                      placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                      rows={3}
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 font-mono focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                      required
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    ⚠️ Only use your public/anon key. Never include service_role secret key.
                  </p>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={handleReset}
                    className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
                  >
                    Reset Default
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-md"
                  >
                    Save & Connect
                  </button>
                </div>
              </form>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700">
                    PostgreSQL Tables & RLS Setup
                  </span>
                  <button
                    onClick={handleCopySQL}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy SQL'}</span>
                  </button>
                </div>

                <div className="max-h-60 overflow-y-auto bg-slate-900 text-slate-100 p-3 rounded-xl text-[10px] font-mono leading-relaxed border border-slate-800">
                  <pre>{schemaSQL}</pre>
                </div>

                <p className="text-[11px] text-slate-500">
                  💡 Copy and run this in your Supabase SQL Editor to instantly provision all tables and security policies.
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
