import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Search,
  Plus,
  MoreVertical,
  User,
  CheckCircle,
  XCircle,
  Trash2,
  Edit2,
  Lock,
  Phone,
  BookOpen,
} from 'lucide-react';
import { Profile } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface ManageStudentsProps {
  onBack: () => void;
  onAssignTests?: (student: Profile) => void;
}

export const ManageStudents: React.FC<ManageStudentsProps> = ({
  onBack,
  onAssignTests,
}) => {
  const [students, setStudents] = useState<Profile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Profile | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [allowedCats, setAllowedCats] = useState<string[]>([
    'Navodaya',
    'NMMS',
    'Gyan Setu',
    'Gyan Sadhana',
    'TET-1',
  ]);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const loadStudents = async () => {
    try {
      setLoading(true);
      const list = await dataService.getProfiles('student');
      setStudents(list);
    } catch {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStudents();
  }, []);

  const openAddModal = () => {
    setEditingStudent(null);
    setName('');
    setPhone('');
    setPassword('');
    setStatus('active');
    setAllowedCats(['Navodaya', 'NMMS', 'Gyan Setu', 'Gyan Sadhana', 'TET-1']);
    setFormError('');
    setShowAddModal(true);
  };

  const openEditModal = (std: Profile) => {
    setEditingStudent(std);
    setName(std.full_name);
    setPhone(std.phone);
    setPassword('');
    setStatus(std.status);
    setAllowedCats(std.allowed_categories || ['Navodaya', 'NMMS']);
    setFormError('');
    setShowAddModal(true);
    setActiveMenuId(null);
  };

  const handleSaveStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('વિદ્યાર્થીનું નામ દાખલ કરો.');
      return;
    }
    if (!phone.trim() || phone.length < 10) {
      setFormError('માન્ય ૧૦ અંકનો મોબાઈલ નંબર દાખલ કરો.');
      return;
    }

    setSaving(true);
    setFormError('');

    try {
      if (editingStudent) {
        await dataService.updateProfile(editingStudent.id, {
          full_name: name.trim(),
          phone: phone.trim(),
          status,
          allowed_categories: allowedCats,
        });
      } else {
        await dataService.addProfile({
          full_name: name.trim(),
          phone: phone.trim(),
          role: 'student',
          status,
          allowed_categories: allowedCats,
        });
      }
      setShowAddModal(false);
      await loadStudents();
    } catch {
      setFormError('વિદ્યાર્થી સેવ કરવામાં ભૂલ આવી.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async (std: Profile) => {
    const newStatus = std.status === 'active' ? 'inactive' : 'active';
    await dataService.updateProfile(std.id, { status: newStatus });
    setActiveMenuId(null);
    await loadStudents();
  };

  const handleDeleteStudent = async (std: Profile) => {
    if (confirm(`શું તમે ખરેખર ${std.full_name} ને ડીલીટ કરવા માંગો છો?`)) {
      await dataService.deleteProfile(std.id);
      setActiveMenuId(null);
      await loadStudents();
    }
  };

  const allCategories = ['Navodaya', 'NMMS', 'Gyan Setu', 'Gyan Sadhana', 'TET-1'];

  const toggleCategory = (cat: string) => {
    if (allowedCats.includes(cat)) {
      setAllowedCats(allowedCats.filter((c) => c !== cat));
    } else {
      setAllowedCats([...allowedCats, cat]);
    }
  };

  const filteredStudents = students.filter(
    (s) =>
      s.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.phone.includes(searchQuery)
  );

  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-blue-900 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-white hover:bg-blue-950 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6">
          Manage Students
        </h1>
      </div>

      {/* Search Bar + Add Button matching Image 2 */}
      <div className="p-4 bg-white border-b border-slate-200 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search student..."
            className="w-full pl-9 pr-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
          />
        </div>

        <button
          onClick={openAddModal}
          className="px-3 py-2 bg-blue-900 hover:bg-blue-950 text-white text-xs font-bold rounded-xl shadow-xs shrink-0 flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Student</span>
        </button>
      </div>

      {/* Student List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="h-16 bg-white border border-slate-200 rounded-2xl animate-pulse"
              />
            ))}
          </div>
        ) : filteredStudents.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
            કોઈ વિદ્યાર્થી મળ્યા નથી.
          </div>
        ) : (
          filteredStudents.map((std) => {
            const isActive = std.status === 'active';

            return (
              <div
                key={std.id}
                className="bg-white border border-slate-200/90 rounded-2xl p-3.5 flex items-center justify-between shadow-xs relative"
              >
                <div className="flex items-center gap-3">
                  {/* Student Avatar */}
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 font-bold text-xs shrink-0 border border-slate-200 overflow-hidden">
                    <User className="w-5 h-5 text-indigo-600" />
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-slate-900 leading-snug">
                      {std.full_name}
                    </h3>
                    <p className="text-[11px] text-slate-500 font-mono">
                      {std.phone}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Status Badge matching Image 2 */}
                  <span
                    className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}
                  >
                    {isActive ? 'Active' : 'Inactive'}
                  </span>

                  {/* 3-dots Menu Button */}
                  <div className="relative">
                    <button
                      onClick={() =>
                        setActiveMenuId(activeMenuId === std.id ? null : std.id)
                      }
                      className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {activeMenuId === std.id && (
                      <div className="absolute right-0 top-8 z-30 w-40 bg-white rounded-xl shadow-xl border border-slate-100 py-1 text-xs">
                        <button
                          onClick={() => openEditModal(std)}
                          className="w-full px-3 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-blue-600" />
                          <span>Edit Student</span>
                        </button>

                        {onAssignTests && (
                          <button
                            onClick={() => {
                              setActiveMenuId(null);
                              onAssignTests(std);
                            }}
                            className="w-full px-3 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                          >
                            <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                            <span>Assign Tests</span>
                          </button>
                        )}

                        <button
                          onClick={() => handleToggleStatus(std)}
                          className="w-full px-3 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          {isActive ? (
                            <>
                              <XCircle className="w-3.5 h-3.5 text-amber-600" />
                              <span>Deactivate</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Activate</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => handleDeleteStudent(std)}
                          className="w-full px-3 py-2 text-left text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">
                {editingStudent ? 'Edit Student' : 'Add New Student'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            {formError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
                {formError}
              </div>
            )}

            <form onSubmit={handleSaveStudent} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Student Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter student name"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mobile Number
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                    placeholder="Enter mobile number"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={editingStudent ? 'Keep existing password' : 'Enter password'}
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required={!editingStudent}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Allowed Exam Categories
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {allCategories.map((cat) => {
                    const isSelected = allowedCats.includes(cat);
                    return (
                      <button
                        type="button"
                        key={cat}
                        onClick={() => toggleCategory(cat)}
                        className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg border transition-colors ${
                          isSelected
                            ? 'bg-blue-900 text-white border-blue-900'
                            : 'bg-slate-50 text-slate-600 border-slate-200'
                        }`}
                      >
                        {cat}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="w-full py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  {saving ? 'Saving...' : 'Save Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
