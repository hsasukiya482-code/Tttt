import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Search,
  Plus,
  MoreVertical,
  UserCheck,
  CheckCircle,
  XCircle,
  Eye,
  EyeOff,
  Trash2,
  Edit2,
  Lock,
  Phone,
  User,
  Shield,
} from 'lucide-react';
import { Profile } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface ManageAdminsProps {
  onBack: () => void;
}

export const ManageAdmins: React.FC<ManageAdminsProps> = ({ onBack }) => {
  const [admins, setAdmins] = useState<Profile[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<Profile | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [showPass, setShowPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const loadAdmins = async () => {
    try {
      setLoading(true);
      const list = await dataService.getProfiles('admin');
      setAdmins(list);
    } catch {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdmins();
  }, []);

  const openAddModal = () => {
    setEditingAdmin(null);
    setName('');
    setPhone('');
    setPassword('');
    setConfirmPassword('');
    setStatus('active');
    setFormError('');
    setShowAddModal(true);
  };

  const openEditModal = (adm: Profile) => {
    setEditingAdmin(adm);
    setName(adm.full_name);
    setPhone(adm.phone);
    setPassword('');
    setConfirmPassword('');
    setStatus(adm.status);
    setFormError('');
    setShowAddModal(true);
    setActiveMenuId(null);
  };

  const handleSaveAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('કૃપા કરીને એડમિનનું નામ દાખલ કરો.');
      return;
    }
    if (!phone.trim() || phone.length < 10) {
      setFormError('માન્ય ૧૦ અંકનો મોબાઈલ નંબર દાખલ કરો.');
      return;
    }

    if (!editingAdmin) {
      if (!password.trim()) {
        setFormError('કૃપા કરીને પાસવર્ડ દાખલ કરો.');
        return;
      }
      if (password !== confirmPassword) {
        setFormError('પાસવર્ડ અને કન્ફર્મ પાસવર્ડ મેળ ખાતા નથી.');
        return;
      }
    } else {
      if (password && password !== confirmPassword) {
        setFormError('પાસવર્ડ અને કન્ફર્મ પાસવર્ડ મેળ ખાતા નથી.');
        return;
      }
    }

    setSaving(true);
    setFormError('');

    try {
      if (password.trim()) {
        dataService.setUserPassword(phone.trim(), password.trim());
      }
      if (editingAdmin) {
        await dataService.updateProfile(editingAdmin.id, {
          full_name: name.trim(),
          phone: phone.trim(),
          status,
        });
      } else {
        await dataService.addProfile({
          full_name: name.trim(),
          phone: phone.trim(),
          role: 'admin',
          status,
        });
      }
      setShowAddModal(false);
      await loadAdmins();
    } catch {
      setFormError('એડમિન સેવ કરવામાં ભૂલ આવી.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleStatus = async (adm: Profile) => {
    const newStatus = adm.status === 'active' ? 'inactive' : 'active';
    await dataService.updateProfile(adm.id, { status: newStatus });
    setActiveMenuId(null);
    await loadAdmins();
  };

  const handleDeleteAdmin = async (adm: Profile) => {
    if (confirm(`શું તમે ખરેખર ${adm.full_name} ને ડીલીટ કરવા માંગો છો?`)) {
      await dataService.deleteProfile(adm.id);
      setActiveMenuId(null);
      await loadAdmins();
    }
  };

  const filteredAdmins = admins.filter(
    (a) =>
      a.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.phone.includes(searchQuery)
  );

  // If in Add/Edit Full Screen View (matching Image 2 "Add New Admin")
  if (showAddModal) {
    return (
      <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
        {/* Top Header */}
        <div className="bg-blue-900 text-white px-4 py-4 flex items-center justify-between shadow-md">
          <button
            onClick={() => setShowAddModal(false)}
            className="p-1 -ml-1 text-white hover:bg-blue-950 rounded-lg transition-colors flex items-center"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6">
            {editingAdmin ? 'Edit Admin' : 'Add New Admin'}
          </h1>
        </div>

        {/* Form Body matching Image 2 */}
        <form onSubmit={handleSaveAdmin} className="flex-1 overflow-y-auto p-5 space-y-4">
          {formError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs">
              {formError}
            </div>
          )}

          {/* Admin Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Admin Name
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter admin name"
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-800"
                required
              />
            </div>
          </div>

          {/* Mobile Number */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Mobile Number
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Phone className="w-4 h-4" />
              </div>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="Enter mobile number"
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-800"
                required
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {editingAdmin ? 'New Password (Optional)' : 'Password'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full pl-10 pr-11 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-800"
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400"
              >
                {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Confirm Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showConfirmPass ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm password"
                className="w-full pl-10 pr-11 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-800"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPass(!showConfirmPass)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400"
              >
                {showConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Status Dropdown */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Status
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')}
              className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>

          {/* Save Button */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={saving}
              className="w-full py-3.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-900/30 transition-all flex items-center justify-center gap-2"
            >
              {saving ? 'Saving...' : 'Save Admin'}
            </button>
          </div>
        </form>
      </div>
    );
  }

  // Manage Admins List Screen
  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-blue-900 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-white hover:bg-blue-950 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6">
          Manage Admins
        </h1>
      </div>

      {/* Search Bar + Add Button matching Image 2 */}
      <div className="p-4 bg-white border-b border-slate-200 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search admin..."
            className="w-full pl-9 pr-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
          />
        </div>

        <button
          onClick={openAddModal}
          className="p-2.5 bg-blue-900 hover:bg-blue-950 text-white rounded-xl shadow-xs shrink-0 flex items-center justify-center"
          title="Add Admin"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Admin List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-16 bg-white border border-slate-200 rounded-2xl animate-pulse"
              />
            ))}
          </div>
        ) : filteredAdmins.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
            કોઈ એડમિન મળ્યા નથી.
          </div>
        ) : (
          filteredAdmins.map((adm) => {
            const isSuper = adm.role === 'super_admin';
            const isActive = adm.status === 'active';

            return (
              <div
                key={adm.id}
                className="bg-white border border-slate-200/90 rounded-2xl p-3.5 flex items-center justify-between shadow-xs relative"
              >
                <div className="flex items-center gap-3">
                  {/* Admin Avatar */}
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-800 font-bold text-xs shrink-0 border border-blue-200">
                    <UserCheck className="w-5 h-5" />
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-slate-900 leading-snug">
                      {adm.full_name}
                    </h3>
                    <p className="text-[11px] text-slate-500 font-mono">
                      {adm.phone}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Role Badge */}
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isSuper
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {isSuper ? 'Super Admin' : 'Admin'}
                  </span>

                  {/* Status Badge */}
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-rose-50 text-rose-700'
                    }`}
                  >
                    {isActive ? 'Active' : 'Inactive'}
                  </span>

                  {/* 3-dots Menu Button */}
                  <div className="relative">
                    <button
                      onClick={() =>
                        setActiveMenuId(activeMenuId === adm.id ? null : adm.id)
                      }
                      className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {activeMenuId === adm.id && (
                      <div className="absolute right-0 top-8 z-30 w-36 bg-white rounded-xl shadow-xl border border-slate-100 py-1 text-xs">
                        <button
                          onClick={() => openEditModal(adm)}
                          className="w-full px-3 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-blue-600" />
                          <span>Edit Admin</span>
                        </button>
                        <button
                          onClick={() => handleToggleStatus(adm)}
                          className="w-full px-3 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          {isActive ? (
                            <>
                              <XCircle className="w-3.5 h-3.5 text-amber-600" />
                              <span>Deactivate</span>
                            </>
                          ) : (
                            <>
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Activate</span>
                            </>
                          )}
                        </button>
                        {!isSuper && (
                          <button
                            onClick={() => handleDeleteAdmin(adm)}
                            className="w-full px-3 py-2 text-left text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Delete</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
