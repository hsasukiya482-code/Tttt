import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Plus,
  Edit,
  Trash2,
  Eye,
  CheckCircle2,
  X,
  HelpCircle,
} from 'lucide-react';
import { Question, Test } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface ManageQuestionsProps {
  test?: Test;
  onBack: () => void;
}

export const ManageQuestions: React.FC<ManageQuestionsProps> = ({
  test,
  onBack,
}) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);

  // Form fields
  const [questionText, setQuestionText] = useState('');
  const [optA, setOptA] = useState('');
  const [optB, setOptB] = useState('');
  const [optC, setOptC] = useState('');
  const [optD, setOptD] = useState('');
  const [correctOpt, setCorrectOpt] = useState<'A' | 'B' | 'C' | 'D'>('A');
  const [explanation, setExplanation] = useState('');
  const [saving, setSaving] = useState(false);

  const testId = test ? test.id : 'test-nav-1';

  const loadQuestions = async () => {
    try {
      setLoading(true);
      const list = await dataService.getQuestions(testId);
      setQuestions(list);
      if (list.length > 0 && !selectedQuestion) {
        setSelectedQuestion(list[0]);
      }
    } catch {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadQuestions();
  }, [testId]);

  const openAddModal = () => {
    setEditingQuestion(null);
    setQuestionText('');
    setOptA('');
    setOptB('');
    setOptC('');
    setOptD('');
    setCorrectOpt('A');
    setExplanation('');
    setShowAddModal(true);
  };

  const openEditModal = (q: Question) => {
    setEditingQuestion(q);
    setSelectedQuestion(q);
    setQuestionText(q.question_text);
    setOptA(q.option_a);
    setOptB(q.option_b);
    setOptC(q.option_c);
    setOptD(q.option_d);
    setCorrectOpt(q.correct_option);
    setExplanation(q.explanation || '');
    setShowAddModal(true);
  };

  const handleSaveQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim() || !optA.trim() || !optB.trim() || !optC.trim() || !optD.trim()) {
      return;
    }

    setSaving(true);
    try {
      if (editingQuestion) {
        await dataService.updateQuestion(editingQuestion.id, {
          question_text: questionText.trim(),
          option_a: optA.trim(),
          option_b: optB.trim(),
          option_c: optC.trim(),
          option_d: optD.trim(),
          correct_option: correctOpt,
          explanation: explanation.trim(),
        });
      } else {
        await dataService.addQuestion({
          test_id: testId,
          question_text: questionText.trim(),
          option_a: optA.trim(),
          option_b: optB.trim(),
          option_c: optC.trim(),
          option_d: optD.trim(),
          correct_option: correctOpt,
          explanation: explanation.trim(),
          question_order: questions.length + 1,
          is_active: true,
        });
      }
      setShowAddModal(false);
      setEditingQuestion(null);
      await loadQuestions();
    } catch {
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedQuestion) return;
    if (confirm(`શું તમે આ પ્રશ્ન ડીલીટ કરવા માંગો છો?`)) {
      await dataService.deleteQuestion(selectedQuestion.id);
      setSelectedQuestion(null);
      await loadQuestions();
    }
  };

  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header matching Image 2 */}
      <div className="bg-blue-900 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-white hover:bg-blue-950 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6 truncate">
          {test ? test.title : 'Questions'}
        </h1>
        <button
          onClick={openAddModal}
          className="px-2.5 py-1 bg-blue-800 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1 shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Question</span>
        </button>
      </div>

      {/* Questions List matching Image 2 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
        {loading ? (
          <div className="space-y-2.5">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="h-16 bg-white border border-slate-200 rounded-2xl animate-pulse"
              />
            ))}
          </div>
        ) : questions.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
            આ ટેસ્ટમાં કોઈ પ્રશ્નો નથી. + Add Question બટન પર ક્લિક કરો.
          </div>
        ) : (
          questions.map((q, idx) => {
            const isSelected = selectedQuestion?.id === q.id;

            return (
              <div
                key={q.id}
                onClick={() => setSelectedQuestion(q)}
                className={`bg-white border rounded-2xl p-3.5 flex items-center justify-between shadow-xs transition-all cursor-pointer ${
                  isSelected
                    ? 'border-blue-800 ring-2 ring-blue-800/20 bg-blue-50/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-2.5 pr-2">
                  <span className="text-xs font-black text-blue-900 shrink-0">
                    Q.{idx + 1}
                  </span>
                  <div>
                    <h3 className="text-xs font-semibold text-slate-900 leading-snug">
                      {q.question_text}
                    </h3>
                    <span className="text-[10px] font-bold text-slate-400 uppercase mt-0.5 inline-block">
                      MCQ
                    </span>
                  </div>
                </div>

                <div className="shrink-0 flex items-center">
                  <span className="w-6 h-6 rounded-full bg-blue-50 text-blue-800 text-[11px] font-bold flex items-center justify-center border border-blue-200">
                    {q.correct_option}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Bottom Action Bar matching Image 2 (Edit, Delete, View) */}
      <div className="p-3 bg-white border-t border-slate-200 flex items-center justify-around">
        <button
          onClick={() => selectedQuestion && openEditModal(selectedQuestion)}
          disabled={!selectedQuestion}
          className="flex flex-col items-center text-blue-900 hover:text-blue-950 disabled:opacity-30 px-3 py-1 font-semibold text-[11px]"
        >
          <Edit className="w-4 h-4 mb-0.5" />
          <span>Edit</span>
        </button>

        <button
          onClick={handleDelete}
          disabled={!selectedQuestion}
          className="flex flex-col items-center text-rose-600 hover:text-rose-700 disabled:opacity-30 px-3 py-1 font-semibold text-[11px]"
        >
          <Trash2 className="w-4 h-4 mb-0.5" />
          <span>Delete</span>
        </button>

        <button
          onClick={() => selectedQuestion && setShowViewModal(true)}
          disabled={!selectedQuestion}
          className="flex flex-col items-center text-indigo-700 hover:text-indigo-900 disabled:opacity-30 px-3 py-1 font-semibold text-[11px]"
        >
          <Eye className="w-4 h-4 mb-0.5" />
          <span>View</span>
        </button>
      </div>

      {/* View Question Modal */}
      {showViewModal && selectedQuestion && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">Question Preview</h3>
              <button
                onClick={() => setShowViewModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs font-bold text-slate-900 bg-slate-50 p-3 rounded-xl">
              {selectedQuestion.question_text}
            </p>

            <div className="space-y-2 text-xs">
              {[
                { k: 'A', text: selectedQuestion.option_a },
                { k: 'B', text: selectedQuestion.option_b },
                { k: 'C', text: selectedQuestion.option_c },
                { k: 'D', text: selectedQuestion.option_d },
              ].map((opt) => (
                <div
                  key={opt.k}
                  className={`p-2.5 rounded-xl border flex items-center justify-between ${
                    opt.k === selectedQuestion.correct_option
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold'
                      : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  <span className="font-mono mr-2">{opt.k}. {opt.text}</span>
                  {opt.k === selectedQuestion.correct_option && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  )}
                </div>
              ))}
            </div>

            {selectedQuestion.explanation && (
              <p className="text-[11px] text-slate-500 bg-blue-50 p-2.5 rounded-xl">
                <span className="font-bold">સમજૂતી:</span> {selectedQuestion.explanation}
              </p>
            )}

            <button
              onClick={() => setShowViewModal(false)}
              className="w-full py-2.5 bg-blue-900 text-white text-xs font-bold rounded-xl"
            >
              બંધ કરો
            </button>
          </div>
        </div>
      )}

      {/* Add / Edit Question Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">Add / Edit Question</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveQuestion} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Question Text (પ્રશ્ન)
                </label>
                <textarea
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  placeholder="e.g. ભારતનું રાષ્ટ્રીય પક્ષી કયું છે?"
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Option A
                  </label>
                  <input
                    type="text"
                    value={optA}
                    onChange={(e) => setOptA(e.target.value)}
                    placeholder="Option A"
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Option B
                  </label>
                  <input
                    type="text"
                    value={optB}
                    onChange={(e) => setOptB(e.target.value)}
                    placeholder="Option B"
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Option C
                  </label>
                  <input
                    type="text"
                    value={optC}
                    onChange={(e) => setOptC(e.target.value)}
                    placeholder="Option C"
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Option D
                  </label>
                  <input
                    type="text"
                    value={optD}
                    onChange={(e) => setOptD(e.target.value)}
                    placeholder="Option D"
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Correct Answer (સાચો વિકલ્પ)
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['A', 'B', 'C', 'D'] as const).map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setCorrectOpt(key)}
                      className={`py-2 rounded-xl text-xs font-bold border transition-colors ${
                        correctOpt === key
                          ? 'bg-emerald-600 text-white border-emerald-600'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      Option {key}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Explanation / સમજૂતી (Optional)
                </label>
                <input
                  type="text"
                  value={explanation}
                  onChange={(e) => setExplanation(e.target.value)}
                  placeholder="e.g. મોર એ ભારતનું રાષ્ટ્રીય પક્ષી છે."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="w-full py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  {saving ? 'Saving...' : 'Save Question'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
