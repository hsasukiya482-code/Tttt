import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Plus,
  MoreVertical,
  Clock,
  HelpCircle,
  Edit2,
  Trash2,
  ListPlus,
  GraduationCap,
  Award,
  BookOpen,
  Sparkles,
  Bookmark,
} from 'lucide-react';
import { Test, ExamCategory } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface ManageTestsProps {
  onBack: () => void;
  onManageQuestions: (test: Test) => void;
}

export const ManageTests: React.FC<ManageTestsProps> = ({
  onBack,
  onManageQuestions,
}) => {
  const [tests, setTests] = useState<Test[]>([]);
  const [categories, setCategories] = useState<ExamCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingTest, setEditingTest] = useState<Test | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [description, setDescription] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [questionLimit, setQuestionLimit] = useState(20);
  const [isActive, setIsActive] = useState(true);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [cats, allTests] = await Promise.all([
        dataService.getCategories(),
        dataService.getTests(),
      ]);
      setCategories(cats);
      setTests(allTests);
      if (cats.length > 0 && !categoryId) {
        setCategoryId(cats[0].id);
      }
    } catch {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openAddModal = () => {
    setEditingTest(null);
    setTitle('');
    setDescription('');
    setDurationMinutes(30);
    setQuestionLimit(20);
    setIsActive(true);
    if (categories.length > 0) setCategoryId(categories[0].id);
    setShowModal(true);
  };

  const openEditModal = (test: Test) => {
    setEditingTest(test);
    setTitle(test.title);
    setCategoryId(test.category_id);
    setDescription(test.description || '');
    setDurationMinutes(test.duration_minutes);
    setQuestionLimit(test.question_limit);
    setIsActive(test.is_active);
    setShowModal(true);
    setActiveMenuId(null);
  };

  const handleSaveTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setSaving(true);
    try {
      if (editingTest) {
        await dataService.updateTest(editingTest.id, {
          title: title.trim(),
          category_id: categoryId,
          description: description.trim(),
          duration_minutes: Number(durationMinutes),
          question_limit: Number(questionLimit),
          is_active: isActive,
        });
      } else {
        await dataService.addTest({
          title: title.trim(),
          category_id: categoryId,
          description: description.trim(),
          duration_minutes: Number(durationMinutes),
          question_limit: Number(questionLimit),
          is_active: isActive,
        });
      }
      setShowModal(false);
      await loadData();
    } catch {
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteTest = async (test: Test) => {
    if (confirm(`શું તમે ખરેખર "${test.title}" ટેસ્ટ ડીલીટ કરવા માંગો છો?`)) {
      await dataService.deleteTest(test.id);
      setActiveMenuId(null);
      await loadData();
    }
  };

  const getCategoryMeta = (catId: string) => {
    const cat = categories.find((c) => c.id === catId);
    if (!cat) return { name: 'Test', color: 'bg-blue-50 text-blue-600', icon: GraduationCap };

    switch (cat.slug) {
      case 'navodaya':
        return { name: 'Navodaya', color: 'bg-[#EAF8EE] text-[#10B981]', icon: GraduationCap };
      case 'nmms':
        return { name: 'NMMS', color: 'bg-[#EBF3FE] text-[#2563EB]', icon: Award };
      case 'gyan-setu':
        return { name: 'Gyan Setu', color: 'bg-[#FEF6E6] text-[#F59E0B]', icon: BookOpen };
      case 'gyan-sadhana':
        return { name: 'Gyan Sadhana', color: 'bg-[#F4EFFE] text-[#7C3AED]', icon: Sparkles };
      case 'tet-1':
        return { name: 'TET-1', color: 'bg-[#FEEFEF] text-[#EF4444]', icon: Bookmark };
      default:
        return { name: cat.name, color: 'bg-blue-50 text-blue-600', icon: GraduationCap };
    }
  };

  const filteredTests = selectedCategory === 'all'
    ? tests
    : tests.filter((t) => t.category_id === selectedCategory);

  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-blue-900 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-white hover:bg-blue-950 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6">
          Manage Tests
        </h1>
      </div>

      {/* Filter Tabs + Add Button */}
      <div className="p-3 bg-white border-b border-slate-200 flex items-center justify-between gap-2 overflow-x-auto">
        <div className="flex items-center gap-1.5 overflow-x-auto py-1">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
              selectedCategory === 'all'
                ? 'bg-blue-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`text-xs font-semibold px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
                selectedCategory === c.id
                  ? 'bg-blue-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>

        <button
          onClick={openAddModal}
          className="px-3 py-1.5 bg-blue-900 hover:bg-blue-950 text-white text-xs font-bold rounded-xl shadow-xs shrink-0 flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Test</span>
        </button>
      </div>

      {/* Tests List matching Image 2 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-20 bg-white border border-slate-200 rounded-2xl animate-pulse"
              />
            ))}
          </div>
        ) : filteredTests.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
            કોઈ ટેસ્ટ મળી નથી.
          </div>
        ) : (
          filteredTests.map((test) => {
            const meta = getCategoryMeta(test.category_id);
            const Icon = meta.icon;

            return (
              <div
                key={test.id}
                className="bg-white border border-slate-200/90 rounded-2xl p-4 flex items-center justify-between shadow-xs relative"
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-11 h-11 rounded-xl ${meta.color} flex items-center justify-center shrink-0 shadow-xs`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      {test.title}
                    </h3>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5 font-medium">
                      <span>{test.question_limit} Questions</span>
                      <span>|</span>
                      <span>{test.duration_minutes} Min</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <div className="relative">
                    <button
                      onClick={() =>
                        setActiveMenuId(activeMenuId === test.id ? null : test.id)
                      }
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>

                    {activeMenuId === test.id && (
                      <div className="absolute right-0 top-8 z-30 w-44 bg-white rounded-xl shadow-xl border border-slate-100 py-1 text-xs">
                        <button
                          onClick={() => {
                            setActiveMenuId(null);
                            onManageQuestions(test);
                          }}
                          className="w-full px-3 py-2 text-left text-blue-700 hover:bg-blue-50 flex items-center gap-2 font-semibold"
                        >
                          <ListPlus className="w-3.5 h-3.5" />
                          <span>Manage Questions</span>
                        </button>
                        <button
                          onClick={() => openEditModal(test)}
                          className="w-full px-3 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-slate-500" />
                          <span>Edit Test</span>
                        </button>
                        <button
                          onClick={() => handleDeleteTest(test)}
                          className="w-full px-3 py-2 text-left text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete Test</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Test Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">
                {editingTest ? 'Edit Test' : 'Add New Test'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveTest} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Test Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Navodaya Test - 1"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Category
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Description
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. માનસિક ક્ષમતા કસોટી"
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Number(e.target.value))}
                    min={5}
                    max={180}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Question Limit
                  </label>
                  <input
                    type="number"
                    value={questionLimit}
                    onChange={(e) => setQuestionLimit(Number(e.target.value))}
                    min={1}
                    max={200}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                    required
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="w-full py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  {saving ? 'Saving...' : 'Save Test'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
