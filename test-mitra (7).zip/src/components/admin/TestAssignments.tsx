import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  Search,
  Plus,
  User,
  BookOpen,
  Trash2,
  CheckCircle,
  ClipboardList,
} from 'lucide-react';
import { Profile, Test, TestAssignment } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface TestAssignmentsProps {
  onBack: () => void;
  preselectedStudent?: Profile | null;
}

export const TestAssignments: React.FC<TestAssignmentsProps> = ({
  onBack,
  preselectedStudent,
}) => {
  const [assignments, setAssignments] = useState<TestAssignment[]>([]);
  const [students, setStudents] = useState<Profile[]>([]);
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    preselectedStudent ? preselectedStudent.id : ''
  );
  const [selectedTestId, setSelectedTestId] = useState<string>('');
  const [saving, setSaving] = useState(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const [asgs, stds, tsts] = await Promise.all([
        dataService.getAssignments(),
        dataService.getProfiles('student'),
        dataService.getTests(),
      ]);
      setAssignments(asgs);
      setStudents(stds);
      setTests(tsts);
      if (stds.length > 0 && !selectedStudentId) {
        setSelectedStudentId(stds[0].id);
      }
      if (tsts.length > 0 && !selectedTestId) {
        setSelectedTestId(tsts[0].id);
      }
    } catch {
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudentId || !selectedTestId) return;

    setSaving(true);
    try {
      await dataService.assignTest(selectedStudentId, selectedTestId);
      setShowAddModal(false);
      await loadData();
    } catch {
    } finally {
      setSaving(false);
    }
  };

  const handleRemove = async (id: string) => {
    if (confirm('શું તમે આ અસાઇનમેન્ટ રદ કરવા માંગો છો?')) {
      await dataService.removeAssignment(id);
      await loadData();
    }
  };

  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-blue-900 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1 -ml-1 text-white hover:bg-blue-950 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6">
          Test Assignments
        </h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-2.5 py-1 bg-blue-800 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1 shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Assign</span>
        </button>
      </div>

      {/* Assignments List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="h-16 bg-white border border-slate-200 rounded-2xl animate-pulse"
              />
            ))}
          </div>
        ) : assignments.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
            હાલ કોઈ ટેસ્ટ અસાઇન કરેલ નથી.
          </div>
        ) : (
          assignments.map((asg) => {
            const student = students.find((s) => s.id === asg.student_id);
            const test = tests.find((t) => t.id === asg.test_id);

            return (
              <div
                key={asg.id}
                className="bg-white border border-slate-200/90 rounded-2xl p-3.5 flex items-center justify-between shadow-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0 border border-purple-100">
                    <ClipboardList className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      {student ? student.full_name : 'Student'}
                    </h3>
                    <p className="text-[11px] text-indigo-700 font-semibold mt-0.5">
                      {test ? test.title : 'Test'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleRemove(asg.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                  title="Remove Assignment"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* Add Assignment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">Assign Test to Student</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAssign} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Student
                </label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.full_name} ({s.phone})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Select Test
                </label>
                <select
                  value={selectedTestId}
                  onChange={(e) => setSelectedTestId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-800"
                >
                  {tests.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="w-full py-2.5 bg-blue-900 hover:bg-blue-950 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                >
                  {saving ? 'Assigning...' : 'Assign Test'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
