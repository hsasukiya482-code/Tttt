import React, { useState } from 'react';
import { Phone, Lock, Eye, EyeOff, ShieldCheck, AlertCircle, User } from 'lucide-react';
import { TestMitraLogo } from '../TestMitraLogo';
import { dataService } from '../../lib/dataService';
import { Profile } from '../../lib/supabase';

interface AdminLoginProps {
  onLoginSuccess: (profile: Profile) => void;
  onSwitchToStudent: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({
  onLoginSuccess,
  onSwitchToStudent,
}) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.trim()) {
      setErrorMessage('કૃપા કરીને એડમિન મોબાઈલ નંબર દાખલ કરો.');
      return;
    }
    if (!password.trim()) {
      setErrorMessage('કૃપા કરીને પાસવર્ડ દાખલ કરો.');
      return;
    }

    setLoading(true);
    setErrorMessage('');

    try {
      const result = await dataService.loginWithPhone(phone, password, 'admin');
      if (result.error) {
        setErrorMessage(result.error);
      } else if (result.profile) {
        onLoginSuccess(result.profile);
      }
    } catch {
      setErrorMessage('એડમિન સર્વર સાથે કનેક્ટ કરવામાં ભૂલ આવી.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 bg-white flex flex-col justify-between p-6 overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-2">
        <span className="text-xs font-bold text-blue-900 tracking-wide flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-700" />
          <span>Admin Portal</span>
        </span>
        <span className="text-[11px] font-medium text-slate-400">
          Super Admin Only
        </span>
      </div>

      {/* Center Branding & Form matching Image 2 */}
      <div className="my-auto py-6">
        <div className="flex flex-col items-center mb-6">
          <TestMitraLogo variant="login_icon" showTagline={false} />
          <h1 className="text-2xl font-black tracking-tight text-blue-950 mt-3 font-sans">
            TEST MITRA
          </h1>
          <p className="text-xs font-bold text-blue-800 mt-0.5">
            Admin Login
          </p>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-rose-700 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Mobile Number */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Mobile Number / Admin ID
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Phone className="w-4 h-4" />
              </div>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="7096684982"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-transparent transition-all"
                disabled={loading}
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-11 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-transparent transition-all"
                disabled={loading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Login Button matching deep blue theme */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-blue-900 hover:bg-blue-950 active:scale-[0.99] text-white font-bold text-sm rounded-xl shadow-lg shadow-blue-900/30 flex items-center justify-center gap-2 transition-all disabled:opacity-60 mt-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <span>Login</span>
            )}
          </button>
        </form>

        {/* Switch to Student */}
        <div className="mt-6 text-center">
          <button
            onClick={onSwitchToStudent}
            className="text-xs font-semibold text-blue-800 hover:text-blue-950 flex items-center justify-center gap-1 mx-auto py-1 px-3 rounded-lg hover:bg-blue-50 transition-colors"
          >
            <User className="w-3.5 h-3.5" />
            <span>Switch to Student Login →</span>
          </button>
        </div>
      </div>

      {/* Footer Version */}
      <div className="text-center pt-2">
        <span className="text-[11px] font-medium text-slate-400">
          Version 1.0.0
        </span>
      </div>
    </div>
  );
};
