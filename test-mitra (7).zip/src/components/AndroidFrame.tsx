import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
  theme?: 'student' | 'admin' | 'neutral';
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  children,
  theme = 'student',
}) => {
  const [time, setTime] = useState('9:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes();
      const formatted = `${hours % 12 || 12}:${minutes < 10 ? '0' : ''}${minutes}`;
      setTime(formatted);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const themeHeaderStyles = {
    student: 'bg-indigo-700 text-white',
    admin: 'bg-blue-800 text-white',
    neutral: 'bg-slate-900 text-white',
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-0 sm:p-4 md:p-6 select-none">
      {/* Mobile Device Mockup Container */}
      <div className="w-full sm:max-w-[430px] h-[100dvh] sm:h-[880px] bg-white sm:rounded-[44px] shadow-2xl overflow-hidden flex flex-col relative border-0 sm:border-[8px] sm:border-slate-800 ring-1 ring-slate-700/50">
        
        {/* Android Status Bar (9:41, Wifi, Signal, Battery) */}
        <div className={`h-8 w-full flex items-center justify-between px-6 shrink-0 z-50 text-xs font-semibold tracking-wider transition-colors ${themeHeaderStyles[theme]}`}>
          <span>{time}</span>
          <div className="flex items-center space-x-2">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center space-x-1">
              <span className="text-[10px]">100%</span>
              <BatteryMedium className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* App Main Body Viewport */}
        <div className="flex-1 flex flex-col overflow-hidden relative bg-slate-50">
          {children}
        </div>

        {/* Android Bottom Navigation Pill */}
        <div className="h-4 w-full bg-white flex items-center justify-center shrink-0 z-40 pb-1">
          <div className="w-32 h-1 bg-slate-300 rounded-full" />
        </div>
      </div>
    </div>
  );
};
