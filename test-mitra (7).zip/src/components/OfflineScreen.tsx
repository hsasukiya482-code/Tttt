import React from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { TestMitraLogo } from './TestMitraLogo';

interface OfflineScreenProps {
  onRetry: () => void;
  isChecking: boolean;
}

export const OfflineScreen: React.FC<OfflineScreenProps> = ({ onRetry, isChecking }) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-between p-6 bg-white text-center">
      <div className="w-full flex justify-center pt-8">
        <TestMitraLogo size="sm" showTagline={false} />
      </div>

      <div className="flex flex-col items-center max-w-xs my-auto">
        <div className="w-24 h-24 bg-rose-50 rounded-full flex items-center justify-center text-rose-500 mb-6 shadow-inner animate-pulse">
          <WifiOff className="w-12 h-12" />
        </div>
        
        <h2 className="text-xl font-bold text-slate-900 mb-2">
          Internet connection required
        </h2>
        <p className="text-sm text-slate-500 mb-2">
          Please check your internet connection and try again.
        </p>
        <p className="text-xs text-indigo-600 font-medium bg-indigo-50 px-3 py-1 rounded-full">
          ઇન્ટરનેટ કનેક્શન ચાલુ કરો
        </p>
      </div>

      <div className="w-full pb-8">
        <button
          onClick={onRetry}
          disabled={isChecking}
          className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white font-semibold rounded-2xl shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 transition-all disabled:opacity-60"
        >
          <RefreshCw className={`w-5 h-5 ${isChecking ? 'animate-spin' : ''}`} />
          {isChecking ? 'Checking connection...' : 'Retry'}
        </button>
      </div>
    </div>
  );
};
