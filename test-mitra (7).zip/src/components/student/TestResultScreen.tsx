import React, { useEffect } from 'react';
import { Trophy, ArrowLeft, RotateCcw, CheckCircle2, XCircle, Award, Target, HelpCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { TestResultData } from './TestScreen';

interface TestResultScreenProps {
  result: TestResultData;
  onBackToHome: () => void;
  onRetakeTest: () => void;
}

export const TestResultScreen: React.FC<TestResultScreenProps> = ({
  result,
  onBackToHome,
  onRetakeTest,
}) => {
  useEffect(() => {
    // Launch celebratory confetti burst
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#2563EB', '#F59E0B', '#10B981', '#7C3AED', '#EC4899'],
      });
    } catch {}
  }, []);

  const isPassed = result.percentage >= 50;

  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-indigo-700 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBackToHome}
          className="p-1.5 -ml-1 text-white hover:bg-indigo-800 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6">
          Test Completed
        </h1>
        <button
          onClick={onRetakeTest}
          className="p-1.5 text-white/80 hover:text-white rounded-lg transition-colors"
          title="Retake"
        >
          <RotateCcw className="w-5 h-5" />
        </button>
      </div>

      {/* Main Result Body */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4">
        {/* Celebration Trophy & Title */}
        <div className="bg-white rounded-3xl p-5 text-center shadow-sm border border-slate-100 flex flex-col items-center">
          <div className="relative mb-3">
            <div className="w-20 h-20 rounded-full bg-amber-50 border-4 border-amber-200 flex items-center justify-center text-amber-500 shadow-inner">
              <Trophy className="w-10 h-10 animate-bounce" />
            </div>
            <div className="absolute -top-1 -right-1 bg-emerald-500 text-white p-1 rounded-full shadow-xs">
              <Award className="w-4 h-4" />
            </div>
          </div>

          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            {isPassed ? 'Great Job!' : 'Good Effort!'}
          </h2>
          <p className="text-xs font-medium text-slate-500 mt-1">
            You have completed the test.
          </p>
          <p className="text-[11px] font-bold text-indigo-700 mt-0.5">
            {result.test.title}
          </p>
        </div>

        {/* Detailed Metrics Card matching Image 2 */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-100 divide-y divide-slate-100">
          <div className="flex items-center justify-between py-2.5">
            <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-600">
              <HelpCircle className="w-4 h-4 text-slate-400" />
              <span>Total Questions</span>
            </div>
            <span className="text-sm font-bold text-slate-900">
              {result.totalQuestions}
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5">
            <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-600">
              <Target className="w-4 h-4 text-blue-500" />
              <span>Attempted</span>
            </div>
            <span className="text-sm font-bold text-slate-900">
              {result.attempted}
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5">
            <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-600">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Correct</span>
            </div>
            <span className="text-sm font-bold text-emerald-600">
              {result.correct}
            </span>
          </div>

          <div className="flex items-center justify-between py-2.5">
            <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-600">
              <XCircle className="w-4 h-4 text-rose-500" />
              <span>Incorrect</span>
            </div>
            <span className="text-sm font-bold text-rose-600">
              {result.incorrect}
            </span>
          </div>

          <div className="flex items-center justify-between pt-3">
            <div className="flex items-center gap-2.5 text-xs font-bold text-indigo-900">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>Score</span>
            </div>
            <div className="text-right">
              <span className="text-base font-black text-indigo-700">
                {result.score} / {result.totalQuestions}
              </span>
              <span className="text-xs font-bold text-slate-500 ml-1.5">
                ({result.percentage}%)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons matching Image 2 */}
      <div className="p-4 bg-white border-t border-slate-200 flex items-center gap-3">
        <button
          onClick={onBackToHome}
          className="flex-1 py-3.5 px-4 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-bold text-xs rounded-2xl shadow-xs transition-all text-center"
        >
          Back to Home
        </button>

        <button
          onClick={onRetakeTest}
          className="flex-1 py-3.5 px-4 bg-indigo-700 hover:bg-indigo-800 active:scale-[0.99] text-white font-bold text-xs rounded-2xl shadow-lg shadow-indigo-600/30 transition-all text-center flex items-center justify-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Retake Test</span>
        </button>
      </div>
    </div>
  );
};
