import React, { useState, useEffect } from 'react';
import {
  Menu,
  Bell,
  GraduationCap,
  Award,
  BookOpen,
  Sparkles,
  Bookmark,
  Home,
  User,
  ChevronRight,
  Megaphone,
} from 'lucide-react';
import { ExamCategory, Profile, Announcement } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface StudentHomeProps {
  student: Profile;
  onSelectCategory: (category: ExamCategory) => void;
  onGoToProfile: () => void;
  onNotificationClick?: () => void;
}

export const StudentHome: React.FC<StudentHomeProps> = ({
  student,
  onSelectCategory,
  onGoToProfile,
}) => {
  const [categories, setCategories] = useState<ExamCategory[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNotificationModal, setShowNotificationModal] = useState(false);

  useEffect(() => {
    async function loadHomeData() {
      try {
        setLoading(true);
        const [cats, anns] = await Promise.all([
          dataService.getCategories(),
          dataService.getAnnouncements(),
        ]);
        setCategories(cats);
        setAnnouncements(anns);
      } catch {
      } finally {
        setLoading(false);
      }
    }
    loadHomeData();
  }, []);

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'GraduationCap':
        return <GraduationCap className="w-8 h-8" />;
      case 'Award':
        return <Award className="w-8 h-8" />;
      case 'BookOpen':
        return <BookOpen className="w-8 h-8" />;
      case 'Sparkles':
        return <Sparkles className="w-8 h-8" />;
      case 'Bookmark':
        return <Bookmark className="w-8 h-8" />;
      default:
        return <GraduationCap className="w-8 h-8" />;
    }
  };

  const getCardStyle = (slug: string) => {
    switch (slug) {
      case 'navodaya':
        return {
          bg: 'bg-[#EAF8EE]',
          border: 'border-[#C1EAD0]',
          iconColor: 'text-[#10B981]',
          badgeColor: 'bg-[#10B981]/10 text-[#0E8A60]',
        };
      case 'nmms':
        return {
          bg: 'bg-[#EBF3FE]',
          border: 'border-[#C6DEFD]',
          iconColor: 'text-[#2563EB]',
          badgeColor: 'bg-[#2563EB]/10 text-[#1D4ED8]',
        };
      case 'gyan-setu':
        return {
          bg: 'bg-[#FEF6E6]',
          border: 'border-[#FDE3B5]',
          iconColor: 'text-[#F59E0B]',
          badgeColor: 'bg-[#F59E0B]/10 text-[#B45309]',
        };
      case 'gyan-sadhana':
        return {
          bg: 'bg-[#F4EFFE]',
          border: 'border-[#DDD0FD]',
          iconColor: 'text-[#7C3AED]',
          badgeColor: 'bg-[#7C3AED]/10 text-[#6D28D9]',
        };
      case 'tet-1':
        return {
          bg: 'bg-[#FEEFEF]',
          border: 'border-[#FCCFCF]',
          iconColor: 'text-[#EF4444]',
          badgeColor: 'bg-[#EF4444]/10 text-[#DC2626]',
        };
      default:
        return {
          bg: 'bg-indigo-50',
          border: 'border-indigo-100',
          iconColor: 'text-indigo-600',
          badgeColor: 'bg-indigo-100 text-indigo-700',
        };
    }
  };

  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-indigo-700 text-white px-5 py-4 flex items-center justify-between shadow-md">
        <button className="p-1.5 -ml-1 text-white/90 hover:text-white rounded-lg active:bg-indigo-800 transition-colors">
          <Menu className="w-6 h-6" />
        </button>
        <h1 className="text-lg font-bold tracking-tight">Home</h1>
        <button
          onClick={() => setShowNotificationModal(!showNotificationModal)}
          className="p-1.5 -mr-1 text-white/90 hover:text-white rounded-lg active:bg-indigo-800 transition-colors relative"
        >
          <Bell className="w-5 h-5" />
          {announcements.length > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-400 rounded-full ring-2 ring-indigo-700" />
          )}
        </button>
      </div>

      {/* Main Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        {/* Welcome Section */}
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-1.5">
            <span>Hello, {student.full_name}</span>
            <span>👋</span>
          </h2>
          <p className="text-xs font-medium text-slate-500 mt-0.5">
            Welcome Back!
          </p>
        </div>

        {/* Announcement Banner */}
        {announcements.length > 0 && (
          <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-2xl p-3.5 text-white shadow-sm flex items-start gap-3">
            <div className="p-2 bg-white/20 rounded-xl shrink-0">
              <Megaphone className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-xs font-bold leading-tight line-clamp-1">
                {announcements[0].title}
              </h3>
              <p className="text-[11px] text-amber-100 mt-0.5 line-clamp-2">
                {announcements[0].message}
              </p>
            </div>
          </div>
        )}

        {/* Available Exams Section */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="text-sm font-bold text-slate-800 tracking-tight">
              Available Exams
            </h3>
            <span className="text-[11px] font-semibold text-indigo-600">
              {categories.length} Categories
            </span>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="h-32 bg-slate-200/70 rounded-2xl animate-pulse"
                />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3.5 pb-2">
              {categories.map((cat, index) => {
                const style = getCardStyle(cat.slug);
                const isFifth = index === 4; // TET-1 centered or full width

                return (
                  <button
                    key={cat.id}
                    onClick={() => onSelectCategory(cat)}
                    className={`${
                      isFifth ? 'col-span-2 sm:col-span-1' : ''
                    } ${style.bg} ${style.border} border p-4 rounded-2xl flex flex-col items-center justify-center text-center shadow-sm hover:shadow-md active:scale-[0.98] transition-all cursor-pointer group`}
                  >
                    <div
                      className={`w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-xs ${style.iconColor} mb-2.5 group-hover:scale-105 transition-transform`}
                    >
                      {getCategoryIcon(cat.icon_name)}
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 leading-tight">
                      {cat.name}
                    </h4>
                    <span
                      className={`text-[10px] font-semibold px-2.5 py-0.5 rounded-full mt-2 inline-flex items-center gap-0.5 ${style.badgeColor}`}
                    >
                      <span>View Tests</span>
                      <ChevronRight className="w-2.5 h-2.5" />
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Notifications Modal */}
      {showNotificationModal && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-5 w-full max-w-xs shadow-xl space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <h3 className="font-bold text-sm text-slate-900">સુચનાઓ (Announcements)</h3>
              <button
                onClick={() => setShowNotificationModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            </div>
            <div className="max-h-60 overflow-y-auto space-y-2">
              {announcements.map((ann) => (
                <div key={ann.id} className="p-2.5 bg-slate-50 rounded-xl text-xs">
                  <h4 className="font-bold text-slate-800">{ann.title}</h4>
                  <p className="text-slate-600 mt-1">{ann.message}</p>
                </div>
              ))}
            </div>
            <button
              onClick={() => setShowNotificationModal(false)}
              className="w-full py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold"
            >
              બંધ કરો (Close)
            </button>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <div className="bg-white border-t border-slate-200 px-6 py-2 flex items-center justify-around shrink-0 shadow-lg">
        <button className="flex flex-col items-center text-indigo-700 py-1 font-semibold">
          <Home className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-bold">Home</span>
        </button>

        <button
          onClick={onGoToProfile}
          className="flex flex-col items-center text-slate-400 hover:text-slate-600 py-1"
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] mt-0.5 font-medium">Profile</span>
        </button>
      </div>
    </div>
  );
};
