import React, { useState } from 'react';
import { Phone, Lock, Eye, EyeOff, LogIn, AlertCircle, Shield } from 'lucide-react';
import { TestMitraLogo } from '../TestMitraLogo';
import { dataService } from '../../lib/dataService';
import { Profile } from '../../lib/supabase';

interface StudentLoginProps {
  onLoginSuccess: (profile: Profile) => void;
  onSwitchToAdmin: () => void;
}

export const StudentLogin: React.FC<StudentLoginProps> = ({
  onLoginSuccess,
  onSwitchToAdmin,
}) => {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone.trim()) {
      setErrorMessage('કૃપા કરીને મોબાઈલ નંબર દાખલ કરો.');
      return;
    }
    if (!password.trim()) {
      setErrorMessage('કૃપા કરીને પાસવર્ડ દાખલ કરો.');
      return;
    }

    setLoading(true);
    setErrorMessage('');

    try {
      const result = await dataService.loginWithPhone(phone, password, 'student');
      if (result.error) {
        setErrorMessage(result.error);
      } else if (result.profile) {
        onLoginSuccess(result.profile);
      }
    } catch {
      setErrorMessage('સર્વર સાથે કનેક્ટ કરવામાં ભૂલ આવી. ફરી પ્રયાસ કરો.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 bg-white flex flex-col justify-between p-6 overflow-y-auto">
      {/* Top Bar Header */}
      <div className="flex items-center justify-between pt-2">
        <span className="text-xs font-semibold text-indigo-700 tracking-wide">
          Student Portal
        </span>
        <span className="text-[11px] font-medium text-slate-400">
          v1.0.0
        </span>
      </div>

      {/* Center Branding & Form */}
      <div className="my-auto py-6">
        <div className="flex flex-col items-center mb-6">
          <TestMitraLogo variant="login_icon" showTagline={false} />
          <h1 className="text-2xl font-black tracking-tight text-indigo-950 mt-3 font-sans">
            TEST MITRA
          </h1>
          <p className="text-xs font-medium text-slate-500 mt-0.5">
            Login to your account
          </p>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-rose-700 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Mobile Number Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Mobile Number
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Phone className="w-4 h-4" />
              </div>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                placeholder="Enter mobile number"
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all"
                disabled={loading}
              />
            </div>
          </div>

          {/* Password Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Password
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full pl-10 pr-11 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all"
                disabled={loading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-indigo-700 hover:bg-indigo-800 active:scale-[0.99] text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all disabled:opacity-60 mt-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>Login</span>
              </>
            )}
          </button>
        </form>

        {/* Switch to Admin */}
        <div className="mt-6 text-center">
          <button
            onClick={onSwitchToAdmin}
            className="text-xs font-semibold text-indigo-700 hover:text-indigo-900 flex items-center justify-center gap-1 mx-auto py-1 px-3 rounded-lg hover:bg-indigo-50 transition-colors"
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Admin Login →</span>
          </button>
        </div>
      </div>

      {/* Footer Version */}
      <div className="text-center pt-2">
        <span className="text-[11px] font-medium text-slate-400">
          Version 1.0.0
        </span>
      </div>
    </div>
  );
};
