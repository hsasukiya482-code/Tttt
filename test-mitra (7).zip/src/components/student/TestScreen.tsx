import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, Clock, Check, X, AlertTriangle } from 'lucide-react';
import { Test, Question } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

export interface TestResultData {
  test: Test;
  totalQuestions: number;
  attempted: number;
  correct: number;
  incorrect: number;
  score: number;
  percentage: number;
}

interface TestScreenProps {
  test: Test;
  onQuit: () => void;
  onComplete: (result: TestResultData) => void;
}

export const TestScreen: React.FC<TestScreenProps> = ({
  test,
  onQuit,
  onComplete,
}) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, 'A' | 'B' | 'C' | 'D'>>({});
  const [loading, setLoading] = useState(true);
  const [secondsRemaining, setSecondsRemaining] = useState(test.duration_minutes * 60);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Load questions
  useEffect(() => {
    async function loadTestQuestions() {
      try {
        setLoading(true);
        const data = await dataService.getQuestions(test.id);
        // Slice to question_limit if needed
        const list = data.slice(0, test.question_limit || 20);
        setQuestions(list);
      } catch {
      } finally {
        setLoading(false);
      }
    }
    loadTestQuestions();
  }, [test]);

  // Countdown Timer
  useEffect(() => {
    if (loading || questions.length === 0) return;

    timerRef.current = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [loading, questions]);

  const formatTimer = (totalSec: number) => {
    const hours = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);
    return `${pad(hours)}:${pad(mins)}:${pad(secs)}`;
  };

  const handleSelectOption = (opt: 'A' | 'B' | 'C' | 'D') => {
    // Only allow selecting once per question for instant validation integrity
    if (selectedAnswers[currentIndex]) return;

    setSelectedAnswers((prev) => ({
      ...prev,
      [currentIndex]: opt,
    }));
  };

  const calculateResults = (): TestResultData => {
    let correctCount = 0;
    let attemptedCount = 0;

    questions.forEach((q, idx) => {
      const userAns = selectedAnswers[idx];
      if (userAns) {
        attemptedCount++;
        if (userAns === q.correct_option) {
          correctCount++;
        }
      }
    });

    const incorrectCount = attemptedCount - correctCount;
    const total = questions.length;
    const score = correctCount;
    const percentage = total > 0 ? Math.round((correctCount / total) * 100) : 0;

    return {
      test,
      totalQuestions: total,
      attempted: attemptedCount,
      correct: correctCount,
      incorrect: incorrectCount,
      score,
      percentage,
    };
  };

  const handleAutoSubmit = () => {
    const result = calculateResults();
    onComplete(result);
  };

  const handleManualSubmit = () => {
    const result = calculateResults();
    onComplete(result);
  };

  if (loading) {
    return (
      <div className="flex-1 bg-white flex flex-col items-center justify-center p-6 text-center">
        <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4" />
        <p className="text-sm font-semibold text-slate-700">પ્રશ્નો લોડ થઈ રહ્યા છે...</p>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="flex-1 bg-white flex flex-col items-center justify-center p-6 text-center">
        <p className="text-sm font-semibold text-slate-700 mb-4">આ ટેસ્ટમાં કોઈ પ્રશ્નો ઉપલબ્ધ નથી.</p>
        <button
          onClick={onQuit}
          className="px-6 py-2.5 bg-indigo-600 text-white text-xs font-bold rounded-xl"
        >
          પાછા જાઓ
        </button>
      </div>
    );
  }

  const currentQ = questions[currentIndex];
  const selectedOpt = selectedAnswers[currentIndex];
  const isAnswered = selectedOpt !== undefined;
  const isCorrect = isAnswered && selectedOpt === currentQ.correct_option;

  const options: Array<{ key: 'A' | 'B' | 'C' | 'D'; text: string }> = [
    { key: 'A', text: currentQ.option_a },
    { key: 'B', text: currentQ.option_b },
    { key: 'C', text: currentQ.option_c },
    { key: 'D', text: currentQ.option_d },
  ];

  return (
    <div className="flex-1 bg-white flex flex-col justify-between overflow-hidden">
      {/* Top Bar with Timer */}
      <div className="bg-indigo-700 text-white px-4 py-3.5 flex items-center justify-between shadow-md">
        <button
          onClick={() => setShowExitConfirm(true)}
          className="p-1 -ml-1 text-white hover:bg-indigo-800 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <h1 className="text-sm font-bold tracking-tight truncate max-w-[160px]">
          {test.title}
        </h1>

        {/* Live Timer Pill */}
        <div className="bg-indigo-900/80 px-2.5 py-1 rounded-full flex items-center gap-1.5 text-xs font-mono font-bold tracking-wider border border-indigo-400/30">
          <Clock className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
          <span>{formatTimer(secondsRemaining)}</span>
        </div>
      </div>

      {/* Main Question Body */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {/* Question Counter */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
          <span className="text-xs font-bold text-indigo-700 uppercase tracking-wider">
            Question {currentIndex + 1} / {questions.length}
          </span>
          <span className="text-xs font-medium text-slate-400">
            {Object.keys(selectedAnswers).length} Answered
          </span>
        </div>

        {/* Question Text */}
        <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl">
          <h2 className="text-base font-bold text-slate-900 leading-relaxed">
            {currentIndex + 1}. {currentQ.question_text}
          </h2>
        </div>

        {/* Options List */}
        <div className="space-y-3">
          {options.map((opt) => {
            const isThisSelected = selectedOpt === opt.key;
            const isThisCorrect = opt.key === currentQ.correct_option;

            let containerStyle =
              'bg-white border-slate-200 text-slate-800 hover:border-indigo-300 hover:bg-indigo-50/20';
            let badgeStyle = 'bg-slate-100 text-slate-700 border-slate-200';

            if (isAnswered) {
              if (isThisCorrect) {
                // Correct Option gets green
                containerStyle = 'bg-emerald-50 border-emerald-500 text-emerald-950 font-semibold ring-1 ring-emerald-500';
                badgeStyle = 'bg-emerald-600 text-white border-emerald-600';
              } else if (isThisSelected && !isThisCorrect) {
                // Incorrect selection gets red
                containerStyle = 'bg-rose-50 border-rose-500 text-rose-950 ring-1 ring-rose-500';
                badgeStyle = 'bg-rose-600 text-white border-rose-600';
              } else {
                containerStyle = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
              }
            }

            return (
              <button
                key={opt.key}
                onClick={() => handleSelectOption(opt.key)}
                disabled={isAnswered}
                className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all active:scale-[0.99] cursor-pointer shadow-xs ${containerStyle}`}
              >
                <div className="flex items-center gap-3.5 pr-2">
                  <span
                    className={`w-8 h-8 rounded-xl border flex items-center justify-center text-xs font-bold shrink-0 ${badgeStyle}`}
                  >
                    {opt.key}
                  </span>
                  <span className="text-sm font-medium leading-snug">
                    {opt.text}
                  </span>
                </div>

                {isAnswered && (
                  <div className="shrink-0 pl-2">
                    {isThisCorrect && (
                      <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shadow-xs">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </div>
                    )}
                    {isThisSelected && !isThisCorrect && (
                      <div className="w-6 h-6 rounded-full bg-rose-500 text-white flex items-center justify-center shadow-xs">
                        <X className="w-4 h-4 stroke-[3]" />
                      </div>
                    )}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Instant Feedback Notice */}
        {isAnswered && (
          <div
            className={`p-3 rounded-2xl text-xs flex items-start gap-2.5 animate-fadeIn ${
              isCorrect
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border border-rose-200 text-rose-800'
            }`}
          >
            {isCorrect ? (
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <X className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-bold">
                {isCorrect ? 'સાચો જવાબ! (Correct Answer)' : 'ખોટો જવાબ (Incorrect Answer)'}
              </p>
              {currentQ.explanation && (
                <p className="text-[11px] mt-0.5 text-slate-600 font-medium">
                  {currentQ.explanation}
                </p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Action Controls */}
      <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
        <button
          onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
          disabled={currentIndex === 0}
          className="flex-1 py-3 px-4 border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs rounded-xl transition-all disabled:opacity-40 disabled:hover:bg-white"
        >
          Previous
        </button>

        {currentIndex < questions.length - 1 ? (
          <button
            onClick={() => setCurrentIndex((prev) => prev + 1)}
            className="flex-1 py-3 px-4 bg-indigo-700 hover:bg-indigo-800 active:scale-[0.99] text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-200 transition-all"
          >
            Next
          </button>
        ) : (
          <button
            onClick={handleManualSubmit}
            className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-200 transition-all"
          >
            Submit Test
          </button>
        )}
      </div>

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-xs shadow-2xl space-y-4 text-center">
            <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-500 mx-auto">
              <AlertTriangle className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              ટેસ્ટ છોડવી છે? (Quit Test?)
            </h3>
            <p className="text-xs text-slate-500">
              જો તમે અત્યારે પાછા જશો તો ટેસ્ટ સબમિટ થશે નહીં.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-2.5 border border-slate-300 text-slate-700 font-bold text-xs rounded-xl"
              >
                ચાલુ રાખો
              </button>
              <button
                onClick={onQuit}
                className="flex-1 py-2.5 bg-rose-600 text-white font-bold text-xs rounded-xl shadow-md shadow-rose-200"
              >
                બહાર નીકળો
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
