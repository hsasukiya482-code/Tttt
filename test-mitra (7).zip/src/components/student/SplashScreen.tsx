import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { TestMitraLogo } from '../TestMitraLogo';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 2400);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div
      onClick={onFinish}
      className="flex-1 bg-gradient-to-b from-slate-50 via-white to-indigo-50 flex flex-col items-center justify-between p-8 text-center cursor-pointer select-none"
    >
      <div className="w-full" />

      {/* Center Mascot & Logo Animation */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="flex flex-col items-center"
      >
        <TestMitraLogo size="xl" showTagline={false} />

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="mt-6 text-center"
        >
          <h1 className="text-3xl font-black tracking-tight text-indigo-900 font-sans">
            TEST MITRA
          </h1>
          <p className="text-base font-semibold text-indigo-600 mt-1">
            Welcome
          </p>
          <p className="text-sm font-medium text-slate-600 mt-1">
            તમારી સફળતાની સાથે સાથે
          </p>
        </motion.div>
      </motion.div>

      {/* Bottom Pagination Dots */}
      <div className="flex items-center space-x-2 pb-6">
        <div className="w-8 h-2 bg-indigo-600 rounded-full animate-pulse" />
        <div className="w-2 h-2 bg-indigo-300 rounded-full" />
        <div className="w-2 h-2 bg-indigo-300 rounded-full" />
        <div className="w-2 h-2 bg-indigo-300 rounded-full" />
      </div>
    </div>
  );
};
