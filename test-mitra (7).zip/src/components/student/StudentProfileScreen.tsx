import React from 'react';
import { ArrowLeft, LogOut, Phone, User, ShieldCheck } from 'lucide-react';
import { Profile } from '../../lib/supabase';

interface StudentProfileScreenProps {
  student: Profile;
  onBack: () => void;
  onLogout: () => void;
}

export const StudentProfileScreen: React.FC<StudentProfileScreenProps> = ({
  student,
  onBack,
  onLogout,
}) => {
  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-indigo-700 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1.5 -ml-1 text-white hover:bg-indigo-800 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-base font-bold tracking-tight text-center flex-1 pr-6">
          My Profile
        </h1>
      </div>

      {/* Profile Details Body matching Image 2 */}
      <div className="flex-1 overflow-y-auto p-6 flex flex-col items-center">
        {/* Rounded Student Avatar */}
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-full bg-indigo-100 border-4 border-white shadow-md flex items-center justify-center overflow-hidden">
            <svg viewBox="0 0 100 100" className="w-full h-full">
              <circle cx="50" cy="50" r="48" fill="#E0E7FF" />
              {/* Hair */}
              <circle cx="50" cy="38" r="22" fill="#1E293B" />
              {/* Face */}
              <circle cx="50" cy="42" r="18" fill="#FED7AA" />
              {/* Eyes */}
              <circle cx="44" cy="40" r="2.5" fill="#1E293B" />
              <circle cx="56" cy="40" r="2.5" fill="#1E293B" />
              {/* Smile */}
              <path d="M45 46 Q50 51 55 46" stroke="#1E293B" strokeWidth="1.5" fill="none" />
              {/* Shirt */}
              <path d="M25 80 C25 65 35 60 50 60 C65 60 75 65 75 80 Z" fill="#4338CA" />
            </svg>
          </div>
          <div className="absolute bottom-0 right-0 bg-emerald-500 text-white p-1.5 rounded-full border-2 border-white shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* Profile Card */}
        <div className="w-full bg-white rounded-3xl p-5 shadow-sm border border-slate-100 space-y-4">
          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
              Name
            </span>
            <div className="flex items-center gap-2.5">
              <User className="w-4 h-4 text-indigo-600" />
              <span className="text-base font-bold text-slate-900">
                {student.full_name}
              </span>
            </div>
          </div>

          <hr className="border-slate-100" />

          <div>
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
              Mobile Number
            </span>
            <div className="flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-indigo-600" />
              <span className="text-base font-bold text-slate-900 font-mono">
                {student.phone}
              </span>
            </div>
          </div>
        </div>

        {/* Info card */}
        <div className="w-full bg-indigo-50/70 border border-indigo-100 rounded-2xl p-3.5 mt-4 text-center">
          <p className="text-xs text-indigo-900 font-medium">
            TEST MITRA Student Portal v1.0.0
          </p>
        </div>
      </div>

      {/* Logout Action Button matching Image 2 */}
      <div className="p-5 bg-white border-t border-slate-200">
        <button
          onClick={onLogout}
          className="w-full py-3.5 bg-white hover:bg-rose-50 border border-rose-200 text-rose-600 font-bold text-xs rounded-2xl flex items-center justify-center gap-2 shadow-xs transition-all active:scale-[0.99]"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};
