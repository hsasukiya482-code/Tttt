import React, { useState, useEffect } from 'react';
import { ChevronLeft, ArrowRight, Clock, HelpCircle, Sparkles } from 'lucide-react';
import { ExamCategory, Test } from '../../lib/supabase';
import { dataService } from '../../lib/dataService';

interface CategoryTestsScreenProps {
  category: ExamCategory;
  onBack: () => void;
  onStartTest: (test: Test) => void;
}

export const CategoryTestsScreen: React.FC<CategoryTestsScreenProps> = ({
  category,
  onBack,
  onStartTest,
}) => {
  const [tests, setTests] = useState<Test[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadTests() {
      try {
        setLoading(true);
        const data = await dataService.getTests(category.id);
        setTests(data);
      } catch {
      } finally {
        setLoading(false);
      }
    }
    loadTests();
  }, [category.id]);

  return (
    <div className="flex-1 bg-slate-50 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="bg-indigo-700 text-white px-4 py-4 flex items-center justify-between shadow-md">
        <button
          onClick={onBack}
          className="p-1.5 -ml-1 text-white hover:bg-indigo-800 rounded-lg transition-colors flex items-center gap-1"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-lg font-bold tracking-tight text-center flex-1 pr-6">
          {category.name}
        </h1>
      </div>

      {/* Main List */}
      <div className="flex-1 overflow-y-auto p-5 space-y-3.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-base font-bold text-slate-800">
            {category.name} Tests
          </h2>
          <span className="text-xs font-semibold text-slate-500">
            {tests.length} Tests available
          </span>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="h-20 bg-white border border-slate-200/80 rounded-2xl animate-pulse"
              />
            ))}
          </div>
        ) : tests.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-3">
            <HelpCircle className="w-12 h-12 text-slate-300 mx-auto" />
            <h3 className="font-bold text-sm text-slate-700">કોઈ ટેસ્ટ ઉપલબ્ધ નથી</h3>
            <p className="text-xs text-slate-500">
              આ કેટેગરીમાં હાલ કોઈ સક્રિય ટેસ્ટ નથી. એડમિન દ્વારા ટૂંક સમયમાં નવી ટેસ્ટ ઉમેરવામાં આવશે.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {tests.map((test) => (
              <button
                key={test.id}
                onClick={() => onStartTest(test)}
                className="w-full bg-white hover:bg-indigo-50/40 active:scale-[0.99] border border-slate-200/90 rounded-2xl p-4 flex items-center justify-between text-left shadow-xs hover:shadow-md transition-all group cursor-pointer"
              >
                <div className="space-y-1 pr-2">
                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-700 transition-colors">
                    {test.title}
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-slate-500 font-medium">
                    <span className="flex items-center gap-1">
                      <HelpCircle className="w-3.5 h-3.5 text-indigo-500" />
                      {test.question_limit} Questions
                    </span>
                    <span className="text-slate-300">|</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-indigo-500" />
                      {test.duration_minutes} Min
                    </span>
                  </div>
                </div>

                <div className="w-9 h-9 rounded-xl bg-indigo-50 group-hover:bg-indigo-600 group-hover:text-white text-indigo-700 flex items-center justify-center shrink-0 transition-colors shadow-xs">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Motivation Banner */}
      <div className="p-4 bg-white border-t border-slate-200 text-center">
        <p className="text-xs font-bold text-indigo-800 bg-indigo-50 py-2.5 px-4 rounded-xl inline-flex items-center gap-1.5 shadow-xs">
          <span>All the best for your exam!</span>
          <Sparkles className="w-4 h-4 text-amber-500" />
        </p>
      </div>
    </div>
  );
};
