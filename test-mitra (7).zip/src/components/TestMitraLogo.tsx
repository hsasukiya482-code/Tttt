import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  className?: string;
  variant?: 'full' | 'badge' | 'login_icon';
}

export const TestMitraLogo: React.FC<LogoProps> = ({
  size = 'md',
  showTagline = true,
  className = '',
  variant = 'full',
}) => {
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-24 h-24',
    lg: 'w-36 h-36',
    xl: 'w-48 h-48',
  };

  // Image 2 Login Shield Badge
  if (variant === 'login_icon') {
    return (
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <div className="relative flex items-center justify-center">
          {/* Blue Shield / Hexagon with Graduation Cap */}
          <div className="w-20 h-20 bg-gradient-to-b from-blue-700 to-indigo-900 rounded-3xl p-1 shadow-lg shadow-blue-500/30 flex items-center justify-center border-2 border-blue-400/40 transform hover:scale-105 transition-transform">
            <svg viewBox="0 0 100 100" className="w-14 h-14 text-white fill-current drop-shadow-md">
              {/* Graduation Cap */}
              <path d="M50 15 L88 34 L50 53 L12 34 Z" fill="#FFFFFF" />
              <path d="M50 57 L80 42 V55 C80 68 50 82 50 82 C50 82 20 68 20 55 V42 Z" fill="#E2E8F0" />
              {/* Tassel */}
              <path d="M80 38 V65" stroke="#FBBF24" strokeWidth="4" strokeLinecap="round" />
              <circle cx="80" cy="67" r="4" fill="#F59E0B" />
              {/* Star / Spark */}
              <circle cx="50" cy="34" r="3" fill="#3B82F6" />
            </svg>
          </div>
        </div>
      </div>
    );
  }

  // Full Logo matching Reference Image 1 exactly
  return (
    <div className={`flex flex-col items-center select-none ${className}`}>
      <div className={`relative ${sizeClasses[size]} flex items-center justify-center`}>
        <svg viewBox="0 0 400 400" className="w-full h-full drop-shadow-xl" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1E40AF" />
              <stop offset="50%" stopColor="#2563EB" />
              <stop offset="100%" stopColor="#4338CA" />
            </linearGradient>
            <linearGradient id="yellowGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FDE047" />
              <stop offset="100%" stopColor="#F59E0B" />
            </linearGradient>
            <linearGradient id="blueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1D4ED8" />
              <stop offset="100%" stopColor="#1E3A8A" />
            </linearGradient>
            <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="0" dy="4" stdDeviation="4" floodOpacity="0.3" />
            </filter>
          </defs>

          {/* Outer Circle Ring */}
          <circle cx="200" cy="200" r="185" fill="none" stroke="#2563EB" strokeWidth="12" />
          <circle cx="200" cy="200" r="175" fill="#EEF2FF" />
          
          {/* Inner Cyan-Sky Background */}
          <circle cx="200" cy="180" r="150" fill="#E0F2FE" />

          {/* Light Bulb Top-Right */}
          <g transform="translate(280, 50) scale(0.6)">
            {/* Rays */}
            <line x1="40" y1="5" x2="40" y2="18" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
            <line x1="15" y1="18" x2="25" y2="28" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
            <line x1="65" y1="18" x2="55" y2="28" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
            <circle cx="40" cy="40" r="22" fill="#FBBF24" />
            <path d="M32 58 H48 V66 H32 Z" fill="#94A3B8" />
          </g>

          {/* Stack of Books on Left */}
          <g transform="translate(45, 120)">
            {/* Green Book */}
            <rect x="0" y="45" width="85" height="18" rx="4" fill="#10B981" />
            <rect x="5" y="47" width="75" height="14" rx="2" fill="#34D399" />
            {/* Orange Book */}
            <rect x="0" y="25" width="90" height="18" rx="4" fill="#F59E0B" />
            <rect x="5" y="27" width="80" height="14" rx="2" fill="#FBBF24" />
            {/* Blue Book with Cap */}
            <rect x="5" y="5" width="85" height="18" rx="4" fill="#2563EB" />
            {/* Mini Graduation Cap on Stack */}
            <path d="M47 -15 L80 -3 L47 9 L14 -3 Z" fill="#1E293B" />
            <path d="M75 -1 V12" stroke="#F59E0B" strokeWidth="2.5" strokeLinecap="round" />
          </g>

          {/* Test Clipboard & Pencil on Right */}
          <g transform="translate(275, 120)">
            <rect x="0" y="0" width="70" height="95" rx="8" fill="#DBEAFE" stroke="#2563EB" strokeWidth="4" />
            <rect x="20" y="-8" width="30" height="14" rx="4" fill="#1E40AF" />
            <text x="35" y="20" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#1E3A8A">TEST</text>
            {/* Checkboxes */}
            <rect x="12" y="30" width="12" height="12" rx="3" fill="#10B981" />
            <path d="M14 36 L17 39 L22 33" fill="none" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
            <line x1="28" y1="36" x2="58" y2="36" stroke="#93C5FD" strokeWidth="3" strokeLinecap="round" />
            <rect x="12" y="48" width="12" height="12" rx="3" fill="none" stroke="#60A5FA" strokeWidth="2" />
            <line x1="28" y1="54" x2="58" y2="54" stroke="#93C5FD" strokeWidth="3" strokeLinecap="round" />
            {/* Yellow Pencil */}
            <g transform="translate(50, 40) rotate(25)">
              <rect x="0" y="0" width="14" height="60" rx="3" fill="#F59E0B" />
              <path d="M0 60 L7 72 L14 60 Z" fill="#FDE68A" />
              <path d="M4 68 L7 72 L10 68 Z" fill="#1E293B" />
              <rect x="0" y="-8" width="14" height="8" rx="2" fill="#F43F5E" />
            </g>
          </g>

          {/* Cheerful Student Mascot (Center) */}
          <g id="mascot">
            {/* Hair Back */}
            <circle cx="200" cy="140" r="58" fill="#1E293B" />
            {/* Face */}
            <ellipse cx="200" cy="145" rx="46" ry="44" fill="#FED7AA" />
            {/* Hair Front Styling */}
            <path d="M152 135 C155 90, 245 90, 248 135 C235 110, 215 115, 200 112 C185 110, 165 115, 152 135 Z" fill="#1E293B" />
            {/* Ears */}
            <circle cx="152" cy="146" r="10" fill="#FED7AA" />
            <circle cx="248" cy="146" r="10" fill="#FED7AA" />
            {/* Eyes & Eyebrows */}
            <ellipse cx="182" cy="142" rx="7" ry="9" fill="#1E293B" />
            <ellipse cx="218" cy="142" rx="7" ry="9" fill="#1E293B" />
            <circle cx="184" cy="139" r="3" fill="#FFFFFF" />
            <circle cx="220" cy="139" r="3" fill="#FFFFFF" />
            <path d="M174 130 Q183 125 192 130" stroke="#1E293B" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            <path d="M208 130 Q217 125 226 130" stroke="#1E293B" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            {/* Cheeks */}
            <circle cx="170" cy="152" r="6" fill="#FDA4AF" opacity="0.6" />
            <circle cx="230" cy="152" r="6" fill="#FDA4AF" opacity="0.6" />
            {/* Smile */}
            <path d="M185 158 Q200 174 215 158" stroke="#1E293B" strokeWidth="3" fill="#EF4444" strokeLinecap="round" />
            {/* School Uniform Collar & Tie */}
            <path d="M170 190 L200 220 L230 190" fill="#FFFFFF" />
            <path d="M195 195 L205 195 L208 230 L200 236 L192 230 Z" fill="#1E40AF" />
            <path d="M150 195 L170 235 L190 235 L175 195 Z" fill="#2563EB" />
            <path d="M250 195 L230 235 L210 235 L225 195 Z" fill="#2563EB" />
            {/* Purple Study Book held */}
            <g transform="translate(205, 185) rotate(-10)">
              <rect x="0" y="0" width="48" height="58" rx="6" fill="#6D28D9" />
              <rect x="3" y="3" width="42" height="52" rx="4" fill="#7C3AED" />
              <text x="24" y="32" textAnchor="middle" fontSize="9" fontWeight="bold" fill="#FFFFFF" letterSpacing="1">STUDY</text>
              {/* Sticky Notes */}
              <rect x="10" y="-6" width="6" height="8" fill="#F43F5E" rx="1" />
              <rect x="20" y="-6" width="6" height="8" fill="#F59E0B" rx="1" />
              <rect x="30" y="-6" width="6" height="8" fill="#10B981" rx="1" />
            </g>
            {/* Thumbs Up Hand Left */}
            <g transform="translate(135, 160)">
              <path d="M15 35 Q10 20 20 10 Q26 12 25 22 L27 23 Q35 25 32 35 L25 45 Z" fill="#FED7AA" stroke="#FDBA74" strokeWidth="1.5" />
            </g>
          </g>

          {/* MAIN BRAND BANNER: [TEST (Blue) | MITRA (Yellow)] */}
          <g transform="translate(25, 230)" filter="url(#shadow)">
            {/* Outer pill container */}
            <rect x="0" y="0" width="350" height="74" rx="37" fill="#0F172A" />
            {/* Left Blue Half */}
            <path d="M37 4 H175 V70 H37 C18 70 4 56 4 37 C4 18 18 4 37 4 Z" fill="url(#blueGrad)" />
            {/* Right Yellow Half */}
            <path d="M175 4 H313 C332 4 346 18 346 37 C346 56 332 70 313 70 H175 Z" fill="url(#yellowGrad)" />
            {/* Border */}
            <rect x="3" y="3" width="344" height="68" rx="34" fill="none" stroke="#FFFFFF" strokeWidth="3.5" />
            
            {/* Typography "TEST" */}
            <text x="90" y="52" textAnchor="middle" fontSize="42" fontFamily="system-ui, sans-serif" fontWeight="900" fill="#FFFFFF" letterSpacing="1">
              TEST
            </text>
            {/* Typography "MITRA" */}
            <text x="260" y="52" textAnchor="middle" fontSize="42" fontFamily="system-ui, sans-serif" fontWeight="900" fill="#0F172A" letterSpacing="1">
              MITRA
            </text>
          </g>

          {/* Tagline White Ribbon Banner */}
          <g transform="translate(50, 305)" filter="url(#shadow)">
            <rect x="0" y="0" width="300" height="34" rx="17" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="2" />
            {/* Gujarati Tagline */}
            <text x="150" y="23" textAnchor="middle" fontSize="17" fontFamily="'Noto Sans Gujarati', system-ui, sans-serif" fontWeight="800" fill="#0F172A">
              તમારી સફળતાની સાચી સાથી
            </text>
            {/* Yellow Accent Dots */}
            <circle cx="22" cy="17" r="4" fill="#F59E0B" />
            <circle cx="278" cy="17" r="4" fill="#F59E0B" />
          </g>

          {/* Bottom Open Book with Green Checkmark */}
          <g transform="translate(140, 335)">
            {/* Open Book Wings */}
            <path d="M60 20 C40 10, 10 15, -30 25 C-30 40, 10 32, 60 48 C110 32, 150 40, 150 25 C110 15, 80 10, 60 20 Z" fill="#DBEAFE" stroke="#2563EB" strokeWidth="3" />
            <circle cx="60" cy="30" r="18" fill="#10B981" stroke="#FFFFFF" strokeWidth="3" />
            <path d="M52 30 L57 35 L68 24" fill="none" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </svg>
      </div>

      {showTagline && (
        <div className="mt-2 text-center">
          <h1 className="text-2xl font-black tracking-tight text-indigo-950 font-sans">TEST MITRA</h1>
          <p className="text-sm font-semibold text-indigo-700">તમારી સફળતાની સાચી સાથી</p>
        </div>
      )}
    </div>
  );
};
